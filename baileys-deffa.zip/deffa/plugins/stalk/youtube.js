import axios from 'axios';
export default {
  id: 'stalk-youtube', name: 'Stalk youtube', category: 'Stalk',
  path: '/api/stalk/youtube', method: 'GET',
  description: 'Lihat profil youtube',
  params: [{ name: 'username', required: true, example: 'siputzx', description: 'Username/handle YouTube' }],
  handler: async (req, getInput) => {
    const q = getInput(req, 'username');
    if (!q) return { ok: false, status: 400, message: "Parameter 'username' wajib diisi." };
    try {
      const { data } = await axios.get('https://api.siputzx.my.id/api/stalk/youtube', { params: { username: q }, timeout: 15000 });
      if (!data?.status) return { ok: false, status: 502, message: 'Gagal mengambil profil.' };
      const d = data.data || {};
      const text = [
        d.title || d.name ? `📺 *${d.title || d.name}*` : '',
        d.customUrl || d.handle ? `🔖 ${d.customUrl || d.handle}` : '',
        d.description ? `📝 ${String(d.description).slice(0, 200)}` : '',
        d.country ? `📍 ${d.country}` : '',
        d.subscriberCount != null ? `👥 Subscribers: ${Number(d.subscriberCount).toLocaleString()}` : '',
        d.videoCount != null ? `🎬 Videos: ${d.videoCount}` : '',
        d.viewCount != null ? `👁️ Views: ${Number(d.viewCount).toLocaleString()}` : '',
        d.url || d.channelUrl ? `🔗 ${d.url || d.channelUrl}` : '',
      ].filter(Boolean).join('\n');
      return { ok: true, type: 'text', result: text || 'Data tidak tersedia.' };
    } catch (err) { return { ok: false, status: 500, message: err.message }; }
  },
};
