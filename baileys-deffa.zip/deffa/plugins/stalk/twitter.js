import axios from 'axios';
export default {
  id: 'stalk-twitter', name: 'Stalk twitter', category: 'Stalk',
  path: '/api/stalk/twitter', method: 'GET',
  description: 'Lihat profil twitter',
  params: [{ name: 'user', required: true, example: 'siputzx', description: 'Username Twitter/X' }],
  handler: async (req, getInput) => {
    const q = getInput(req, 'user');
    if (!q) return { ok: false, status: 400, message: "Parameter 'user' wajib diisi." };
    try {
      const { data } = await axios.get('https://api.siputzx.my.id/api/stalk/twitter', { params: { user: q }, timeout: 15000 });
      if (!data?.status) return { ok: false, status: 502, message: 'Gagal mengambil profil.' };
      const d = data.data || {};
      const text = [
        d.name ? `👤 *${d.name}*` : '',
        d.username || d.screen_name ? `🔖 @${d.username || d.screen_name}` : '',
        d.description ? `📝 ${d.description}` : '',
        d.location ? `📍 ${d.location}` : '',
        d.followers_count != null ? `👥 Followers: ${Number(d.followers_count).toLocaleString()}` : '',
        d.friends_count != null ? `➡️ Following: ${Number(d.friends_count).toLocaleString()}` : '',
        d.statuses_count != null ? `🐦 Tweets: ${Number(d.statuses_count).toLocaleString()}` : '',
        d.verified ? '✅ Verified' : '',
      ].filter(Boolean).join('\n');
      return { ok: true, type: 'text', result: text || 'Data tidak tersedia.' };
    } catch (err) { return { ok: false, status: 500, message: err.message }; }
  },
};
