import axios from 'axios';
export default {
  id: 'stalk-pinterest', name: 'Stalk pinterest', category: 'Stalk',
  path: '/api/stalk/pinterest', method: 'GET',
  description: 'Lihat profil pinterest',
  params: [{ name: 'q', required: true, example: 'dims', description: 'Username Pinterest' }],
  handler: async (req, getInput) => {
    const q = getInput(req, 'q');
    if (!q) return { ok: false, status: 400, message: "Parameter 'q' wajib diisi." };
    try {
      const { data } = await axios.get('https://api.siputzx.my.id/api/stalk/pinterest', { params: { q: q }, timeout: 15000 });
      if (!data?.status) return { ok: false, status: 502, message: 'Gagal mengambil profil.' };
      const d = data.data || {};
      const text = [
        d.fullName || d.name ? `👤 *${d.fullName || d.name}*` : '',
        d.username ? `🔖 @${d.username}` : '',
        d.about ? `📝 ${d.about}` : '',
        d.location ? `📍 ${d.location}` : '',
        d.followerCount != null ? `👥 Followers: ${Number(d.followerCount).toLocaleString()}` : '',
        d.followCount != null ? `➡️ Following: ${Number(d.followCount).toLocaleString()}` : '',
        d.pinCount != null ? `📌 Pins: ${d.pinCount}` : '',
        d.boardCount != null ? `📋 Boards: ${d.boardCount}` : '',
      ].filter(Boolean).join('\n');
      return { ok: true, type: 'text', result: text || 'Data tidak tersedia.' };
    } catch (err) { return { ok: false, status: 500, message: err.message }; }
  },
};
