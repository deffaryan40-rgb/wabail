// config.js — isi sesuai kebutuhan
export default {
  supabase: {
    url: process.env.SUPABASE_URL || '',
    serviceKey: process.env.SUPABASE_KEY || '',
    bucket: process.env.SUPABASE_BUCKET || 'deffa-media',
  },
  smtp: {
    user: process.env.SMTP_USER || '',
    pass: process.env.SMTP_PASS || '',
  },
};
