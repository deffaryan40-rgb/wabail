/** @module Errors */
import type Client from "../Client";
import type { IntentNames } from "../Constants";
/** An error that is thrown when we encounter an error, and no `error` listeners are present. */
export declare class UncaughtError extends Error {
    name: string;
    constructor(error: Error | string);
}
/** An error ancountered when an object is unexpectedly not cached. */
export declare class UncachedError extends Error {
    name: string;
    constructor(...args: [message: string] | [clazz: object, property: string, intent: IntentNames, client?: Client]);
}
/** An error encountered within {@link InteractionOptionsWrapper | InteractionOptionsWrapper} & {@link SelectMenuValuesWrapper | SelectMenuValuesWrapper}. */
export declare class WrapperError extends Error {
    name: string;
    constructor(message: string);
}
/** An error encountered when a needed dependency is missing. */
export declare class DependencyError extends Error {
    name: string;
    constructor(message: string);
}
/** A gateway error. */
export declare class GatewayError extends Error {
    code: number;
    name: string;
    constructor(message: string, code: number);
}
export declare class RateLimitedError extends Error {
    delay: number;
    name: string;
    constructor(message: string, delay: number);
}
export declare class NotImplementedError extends Error {
    name: string;
    constructor(message?: string);
}
export declare class FrozenModificationError extends Error {
    name: string;
    property: string | symbol;
    constructor(detail: string | undefined, prop: string | symbol);
}
