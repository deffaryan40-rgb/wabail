// File: plugins/maker/bratvid.js

import axios from 'axios';

export default {
  id:          'maker-bratvid',
  name:        'Bratvid',
  category:    'Maker',
  path:        '/api/maker/bratvid',
  method:      'GET',
  description: 'Brat meme animated (auto sticker video)',
  asSticker:   true,

  params: [
    {
      name: 'text',
      required: true,
      example: 'ayo scroll fesnuk 😜',
      description: 'Input text',
    },
    {
      name: 'delay',
      required: false,
      example: '500',
      description: 'Delay antar frame animasi (ms), default 500',
    }
  ],

  handler: async (req, getInput, res) => {
    const text  = getInput(req, 'text');
    const delay = getInput(req, 'delay') || '500';
    if (!text) return { ok: false, status: 400, message: "Parameter 'text' wajib diisi." };

    try {
      const response = await axios.get('https://api.siputzx.my.id/api/m/brat', {
        params: { text, isAnimated: 'true', delay },
        timeout: 30000,
        responseType: 'arraybuffer',
        headers: { 'User-Agent': 'Deffa/1.0' },
      });

      const buffer = Buffer.from(response.data);
      if (!buffer || buffer.length < 100) {
        return { ok: false, status: 502, message: 'Upstream tidak mengembalikan video.' };
      }

      return { ok: true, type: 'sticker', isVideo: true, buffer };
    } catch (err) {
      return { ok: false, status: 500, message: err.message || 'Internal server error.' };
    }
  },
};
