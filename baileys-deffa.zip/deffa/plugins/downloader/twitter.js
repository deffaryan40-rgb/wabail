import axios from 'axios';
export default {
  id: 'dl-twitter', name: 'Twitter/X Downloader', category: 'Downloader',
  path: '/api/d/twitter', method: 'GET',
  description: 'Download video Twitter/X',
  params: [{ name: 'url', required: true, example: 'https://twitter.com/user/status/123', description: 'URL tweet' }],
  handler: async (req, getInput) => {
    const url = getInput(req, 'url');
    if (!url) return { ok: false, status: 400, message: "Parameter 'url' wajib diisi." };
    try {
      const { data } = await axios.get('https://api.siputzx.my.id/api/d/twitter', { params: { url }, timeout: 20000 });
      if (!data?.status) return { ok: false, status: 502, message: 'Gagal mengunduh.' };
      const videoUrl = data.data?.url || (Array.isArray(data.data?.media) && data.data.media[0]?.url);
      const caption = data.data?.title || data.data?.text || 'Twitter/X Video';
      if (!videoUrl) return { ok: false, status: 502, message: 'URL video tidak ditemukan.' };
      return { ok: true, type: 'video', url: videoUrl, caption };
    } catch (err) { return { ok: false, status: 500, message: err.message }; }
  },
};
