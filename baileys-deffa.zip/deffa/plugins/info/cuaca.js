import axios from 'axios';
export default {
  id: 'info-cuaca', name: 'Cuaca BMKG', category: 'Info',
  path: '/api/info/cuaca', method: 'GET',
  description: 'Prakiraan cuaca per wilayah dari BMKG',
  params: [{ name: 'q', required: true, example: 'jakarta', description: 'Nama wilayah' }],
  handler: async (req, getInput) => {
    const q = getInput(req, 'q');
    if (!q) return { ok: false, status: 400, message: "Parameter 'q' wajib diisi." };
    try {
      const { data } = await axios.get('https://api.siputzx.my.id/api/info/cuaca', { params: { q }, timeout: 15000 });
      if (!data?.status) return { ok: false, status: 502, message: 'Gagal mengambil data cuaca.' };
      const d = data.data || {};
      const lokasi = d.lokasi || d.wilayah || d.area || q;
      const list = Array.isArray(d.prakiraan || d.cuaca || d.data) ? (d.prakiraan || d.cuaca || d.data) : [];
      const rows = list.slice(0, 5).map(x =>
        `⏰ ${x.waktu || x.time || ''} — ${x.cuaca || x.kondisi || x.weather || ''} | 🌡️ ${x.suhu || x.temp || ''}°C | 💧 ${x.kelembaban || x.humidity || ''}%`
      ).join('\n');
      const text = `🌤️ *Cuaca ${lokasi}*\n\n${rows || JSON.stringify(d, null, 2)}`;
      return { ok: true, type: 'text', result: text };
    } catch (err) { return { ok: false, status: 500, message: err.message }; }
  },
};
