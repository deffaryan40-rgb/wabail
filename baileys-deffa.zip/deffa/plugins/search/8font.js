import axios from 'axios';
export default {
  id: 'search-8font', name: 'Search 8font', category: 'Search',
  path: '/api/s/8font', method: 'GET',
  description: 'Cari konten di 8font',
  params: [{ name: 'query', required: true, example: 'cartoon', description: 'Kata kunci pencarian' }],
  handler: async (req, getInput) => {
    const q = getInput(req, 'query');
    if (!q) return { ok: false, status: 400, message: "Parameter 'query' wajib diisi." };
    try {
      const { data } = await axios.get('https://api.siputzx.my.id/api/s/8font', { params: { query: q }, timeout: 15000 });
      if (!data?.status) return { ok: false, status: 502, message: 'Gagal mencari.' };
      const arr = Array.isArray(data.data) ? data.data : (data.data ? [data.data] : []);
      const text = arr.slice(0,8).map((x,i)=>`${i+1}. ${x.text||x.name||String(x)}`).join('\n');
      return { ok: true, type: 'text', result: text || 'Tidak ada hasil.' };
    } catch (err) { return { ok: false, status: 500, message: err.message }; }
  },
};
