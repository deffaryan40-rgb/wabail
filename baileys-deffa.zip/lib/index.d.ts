export * from "../WAProto/index.js";
export * from "./Utils/index.js";
export * from "./Types/index.js";
export * from "./Store/index.js";
export * from "./Defaults/index.js";
export * from "./WABinary/index.js";
export * from "./WAM/index.js";
export * from "./WAUSync/index.js";

import makeWASocket from './Socket/index.js';
export { makeWASocket };
export default makeWASocket;

// ── Telegram ────────────────────────────────────────────────────────
export declare class DeffaTelegraf {
  constructor(token: string, options?: Record<string, any>);
  launch(options?: Record<string, any>): Promise<void>;
  stop(reason?: string): void;
  on(event: string, handler: (...args: any[]) => any): this;
  use(...middleware: any[]): this;
  command(command: string, ...handlers: any[]): this;
  hears(text: string | RegExp, ...handlers: any[]): this;
  [key: string]: any;
}
export declare class Composer {
  use(...middleware: any[]): this;
  on(event: string, ...handlers: any[]): this;
  command(command: string, ...handlers: any[]): this;
  hears(text: string | RegExp, ...handlers: any[]): this;
  [key: string]: any;
}
export declare class Context {
  message?: Record<string, any>;
  chat?: Record<string, any>;
  from?: Record<string, any>;
  reply(text: string, extra?: Record<string, any>): Promise<any>;
  replyWithPhoto(photo: any, extra?: Record<string, any>): Promise<any>;
  replyWithVideo(video: any, extra?: Record<string, any>): Promise<any>;
  [key: string]: any;
}
export declare class Router {
  [key: string]: any;
}
export declare class Telegram {
  constructor(token: string);
  sendMessage(chatId: number | string, text: string, extra?: Record<string, any>): Promise<any>;
  [key: string]: any;
}
export declare class TelegramError extends Error {
  code: number;
  description: string;
}
export declare function telegramSession(options?: Record<string, any>): any;
export declare class MemorySessionStore {
  get(key: string): any;
  set(key: string, session: any): void;
  delete(key: string): void;
}
export declare function deunionize(value: any): any;
export declare namespace TelegramTypes {}
export declare namespace TelegramMarkup {
  function inlineKeyboard(buttons: any[][]): any;
  function keyboard(buttons: any[][]): any;
  function button(text: string): any;
  function callbackButton(text: string, data: string): any;
  function urlButton(text: string, url: string): any;
}
export declare namespace TelegramInput {
  function fromLocalFile(path: string, filename?: string): any;
  function fromURL(url: string, filename?: string): any;
  function fromBuffer(buffer: Buffer, filename?: string): any;
}
export declare namespace TelegramFormat {
  function bold(text: string): string;
  function italic(text: string): string;
  function code(text: string): string;
  function pre(text: string, language?: string): string;
  function link(text: string, url: string): string;
}
export declare namespace TelegramScenes {
  class BaseScene {
    id: string;
    enter(...handlers: any[]): this;
    leave(...handlers: any[]): this;
    on(event: string, ...handlers: any[]): this;
    command(command: string, ...handlers: any[]): this;
    [key: string]: any;
  }
  class Stage {
    constructor(scenes: BaseScene[], options?: Record<string, any>);
    middleware(): any;
    [key: string]: any;
  }
  class WizardScene extends BaseScene {
    constructor(id: string, ...steps: any[]);
  }
}
export declare function connectTelegram(token: string): Promise<Record<string, any> | null>;

// ── Discord ────────────────────────────────────────────────────────
export declare class Client {
  constructor(options?: Record<string, any>);
  connect(): Promise<void>;
  disconnect(): void;
  on(event: string, handler: (...args: any[]) => any): this;
  [key: string]: any;
}
export declare const Constants: Record<string, any>;
export declare class Shard { [key: string]: any; }
export declare class ShardManager { [key: string]: any; }
export declare class Dispatcher { [key: string]: any; }
export declare const RESTManager: any;
export declare class Guild { [key: string]: any; }
export declare class GuildChannel { [key: string]: any; }
export declare class GuildPreview { [key: string]: any; }
export declare class GuildScheduledEvent { [key: string]: any; }
export declare class GuildTemplate { [key: string]: any; }
export declare class Message { [key: string]: any; }
export declare class Member { [key: string]: any; }
export declare class Integration { [key: string]: any; }
export declare class Invite { [key: string]: any; }
export declare class InviteGuild { [key: string]: any; }
export declare class InviteRole { [key: string]: any; }
export declare class Lobby { [key: string]: any; }
export declare class LobbyMember { [key: string]: any; }
export declare class MediaChannel { [key: string]: any; }
export declare class ForumChannel { [key: string]: any; }
export declare class GroupChannel { [key: string]: any; }
export declare class ExtendedUser { [key: string]: any; }
export declare class OAuthGuild { [key: string]: any; }
export declare class OAuthApplication { [key: string]: any; }
export declare class ModalSubmitInteraction { [key: string]: any; }
export declare class ModalSubmitInteractionComponentsWrapper { [key: string]: any; }
export declare class MessageInteractionResponse { [key: string]: any; }
export declare class InteractionOptionsWrapper { [key: string]: any; }
export declare class InteractionResolvedChannel { [key: string]: any; }
export declare function connectDiscord(options: Record<string, any>): Promise<Client>;

// ── Plugins & Utils ────────────────────────────────────────────────
export declare const plugins: Record<string, (...args: any[]) => Promise<any>>;
export declare function listPlugins(): string[];

export declare function testMessage(
  sock: ReturnType<typeof makeWASocket>,
  jid: string,
  opts?: { quoted?: any; delay?: number }
): Promise<void>;

// ── Plugin named exports ───────────────────────────────────────────
export declare const deffaCommands: Record<string, any>;
export declare const ai: (...args: any[]) => Promise<any>;
export declare const deepseek: (...args: any[]) => Promise<any>;
export declare const qwq: (...args: any[]) => Promise<any>;
export declare const glm: (...args: any[]) => Promise<any>;
export declare const gpt: (...args: any[]) => Promise<any>;
export declare const gita: (...args: any[]) => Promise<any>;
export declare const cnbc: (...args: any[]) => Promise<any>;
export declare const cnn: (...args: any[]) => Promise<any>;
export declare const kompas: (...args: any[]) => Promise<any>;
export declare const antara: (...args: any[]) => Promise<any>;
export declare const liputan6: (...args: any[]) => Promise<any>;
export declare const merdeka: (...args: any[]) => Promise<any>;
export declare const sindo: (...args: any[]) => Promise<any>;
export declare const tribun: (...args: any[]) => Promise<any>;
export declare const tiktok: (...args: any[]) => Promise<any>;
export declare const tiktokhd: (...args: any[]) => Promise<any>;
export declare const twitter: (...args: any[]) => Promise<any>;
export declare const fb: (...args: any[]) => Promise<any>;
export declare const douyin: (...args: any[]) => Promise<any>;
export declare const snack: (...args: any[]) => Promise<any>;
export declare const soundcloud: (...args: any[]) => Promise<any>;
export declare const ummy: (...args: any[]) => Promise<any>;
export declare const lahelu: (...args: any[]) => Promise<any>;
export declare const yt: (...args: any[]) => Promise<any>;
export declare const brave: (...args: any[]) => Promise<any>;
export declare const ddg: (...args: any[]) => Promise<any>;
export declare const bimg: (...args: any[]) => Promise<any>;
export declare const pin: (...args: any[]) => Promise<any>;
export declare const resep: (...args: any[]) => Promise<any>;
export declare const mcpedl: (...args: any[]) => Promise<any>;
export declare const manga: (...args: any[]) => Promise<any>;
export declare const otaku: (...args: any[]) => Promise<any>;
export declare const apple: (...args: any[]) => Promise<any>;
export declare const cuaca: (...args: any[]) => Promise<any>;
export declare const bmkg: (...args: any[]) => Promise<any>;
export declare const jadwaltv: (...args: any[]) => Promise<any>;
export declare const brat: (...args: any[]) => Promise<any>;
export declare const bratvid: (...args: any[]) => Promise<any>;
export declare const github: (...args: any[]) => Promise<any>;
export declare const seegore: (...args: any[]) => Promise<any>;
export declare const sfont: (...args: any[]) => Promise<any>;
export declare const myinstants: (...args: any[]) => Promise<any>;
export declare const scsearch: (...args: any[]) => Promise<any>;
export declare const stalktwitter: (...args: any[]) => Promise<any>;
export declare const stalktiktok: (...args: any[]) => Promise<any>;
export declare const stalkyt: (...args: any[]) => Promise<any>;
export declare const stalkgithub: (...args: any[]) => Promise<any>;
export declare const stalkpin: (...args: any[]) => Promise<any>;
export declare const stalkthreads: (...args: any[]) => Promise<any>;

//# sourceMappingURL=index.d.ts.map
