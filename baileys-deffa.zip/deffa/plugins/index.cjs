"use strict";

// CJS shim for deffa plugins
// Usage: const { tiktok, cnbc } = require('deffa-baileys/plugins')
// Note: requires Node 18+ with ESM interop

let _cache = null;

async function _load() {
  if (_cache) return _cache;
  const mod = await import('./index.js');
  _cache = mod;
  return mod;
}

module.exports = new Proxy({}, {
  get(_, prop) {
    if (prop === 'then' || prop === '__esModule') return undefined;
    return async function(...args) {
      const mod = await _load();
      const fn = mod[prop];
      if (typeof fn !== 'function') throw new Error(`Plugin '${prop}' not found in deffa-baileys`);
      return fn(...args);
    };
  }
});
