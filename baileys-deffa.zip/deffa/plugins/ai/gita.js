import axios from 'axios';
export default {
  id: 'ai-gita', name: 'Gita AI', category: 'AI',
  path: '/api/ai/gita', method: 'GET',
  description: 'Tanya Bhagavad Gita AI',
  params: [{ name: 'q', required: true, example: 'What is karma?', description: 'Pertanyaan' }],
  handler: async (req, getInput) => {
    const q = getInput(req, 'q');
    if (!q) return { ok: false, status: 400, message: "Parameter 'q' wajib diisi." };
    try {
      const { data } = await axios.get('https://api.siputzx.my.id/api/ai/gita', { params: { q }, timeout: 20000 });
      if (!data?.status) return { ok: false, status: 502, message: 'Gagal mendapat respons.' };
      return { ok: true, type: 'text', result: data.data };
    } catch (err) { return { ok: false, status: 500, message: err.message }; }
  },
};
