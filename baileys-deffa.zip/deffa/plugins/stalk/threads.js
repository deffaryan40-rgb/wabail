import axios from 'axios';
export default {
  id: 'stalk-threads', name: 'Stalk threads', category: 'Stalk',
  path: '/api/stalk/threads', method: 'GET',
  description: 'Lihat profil threads',
  params: [{ name: 'q', required: true, example: 'google', description: 'Username Threads' }],
  handler: async (req, getInput) => {
    const q = getInput(req, 'q');
    if (!q) return { ok: false, status: 400, message: "Parameter 'q' wajib diisi." };
    try {
      const { data } = await axios.get('https://api.siputzx.my.id/api/stalk/threads', { params: { q: q }, timeout: 15000 });
      if (!data?.status) return { ok: false, status: 502, message: 'Gagal mengambil profil.' };
      const d = data.data || {};
      const text = [
        d.name || d.username ? `👤 *${d.name || d.username}*` : '',
        d.username ? `🔖 @${d.username}` : '',
        d.bio ? `📝 ${d.bio}` : '',
        d.followers != null ? `👥 Followers: ${Number(d.followers).toLocaleString()}` : '',
        d.verified ? '✅ Verified' : '',
      ].filter(Boolean).join('\n');
      return { ok: true, type: 'text', result: text || 'Data tidak tersedia.' };
    } catch (err) { return { ok: false, status: 500, message: err.message }; }
  },
};
