import axios from 'axios';
export default {
  id: 'dl-douyin', name: 'Douyin Downloader', category: 'Downloader',
  path: '/api/d/douyin', method: 'GET',
  description: 'Download video Douyin',
  params: [{ name: 'url', required: true, example: 'https://www.douyin.com/video/xxx', description: 'URL video Douyin' }],
  handler: async (req, getInput) => {
    const url = getInput(req, 'url');
    if (!url) return { ok: false, status: 400, message: "Parameter 'url' wajib diisi." };
    try {
      const { data } = await axios.get('https://api.siputzx.my.id/api/d/douyin', { params: { url }, timeout: 20000 });
      if (!data?.status) return { ok: false, status: 502, message: 'Gagal mengunduh.' };
      const videoUrl = data.data?.play || data.data?.wmplay;
      const caption = data.data?.title || data.data?.desc || 'Douyin Video';
      if (!videoUrl) return { ok: false, status: 502, message: 'URL video tidak ditemukan.' };
      return { ok: true, type: 'video', url: videoUrl, caption };
    } catch (err) { return { ok: false, status: 500, message: err.message }; }
  },
};
