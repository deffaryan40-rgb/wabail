import axios from 'axios';
export default {
  id: 'ai-gptoss120b', name: 'gptoss120b', category: 'AI',
  path: '/api/ai/gptoss120b', method: 'GET',
  description: 'Chat dengan gptoss120b via siputzx',
  params: [
    { name: 'prompt', required: true, example: 'Halo, siapa kamu?', description: 'Prompt pengguna' },
    { name: 'system', required: false, example: 'You are a helpful assistant.', description: 'System prompt' },
    { name: 'temperature', required: false, example: '0.7', description: 'Temperature (0-1)' },
  ],
  handler: async (req, getInput) => {
    const prompt = getInput(req, 'prompt');
    if (!prompt) return { ok: false, status: 400, message: "Parameter 'prompt' wajib diisi." };
    try {
      const { data } = await axios.get('https://api.siputzx.my.id/api/ai/gptoss120b', {
        params: { prompt, system: getInput(req, 'system') || undefined, temperature: getInput(req, 'temperature') || undefined },
        timeout: 30000,
      });
      if (!data?.status) return { ok: false, status: 502, message: 'Gagal mendapat respons.' };
      const raw = data.data?.response || '';
      const result = raw.replace(/<think>[\s\S]*?<\/think>\s*/i, '').trim();
      return { ok: true, type: 'text', result };
    } catch (err) {
      return { ok: false, status: 500, message: err.message };
    }
  },
};
