import axios from 'axios';
export default {
  id: 'search-brave', name: 'Search Brave', category: 'Search',
  path: '/api/s/brave', method: 'GET',
  description: 'Web search via Brave',
  params: [
    { name: 'query', required: true, example: 'apa itu nodejs', description: 'Kata kunci pencarian' },
    { name: 'kl', required: false, example: 'id-id', description: 'Region (id-id, us-en, dll)' },
    { name: 'df', required: false, example: 'w', description: 'Filter waktu (d=hari, w=minggu, m=bulan)' },
  ],
  handler: async (req, getInput) => {
    const query = getInput(req, 'query');
    if (!query) return { ok: false, status: 400, message: "Parameter 'query' wajib diisi." };
    try {
      const { data } = await axios.get('https://api.siputzx.my.id/api/s/brave', {
        params: { query, kl: getInput(req, 'kl'), df: getInput(req, 'df') }, timeout: 15000,
      });
      if (!data?.status) return { ok: false, status: 502, message: 'Gagal mencari.' };
      const arr = Array.isArray(data.data) ? data.data : (data.data ? [data.data] : []);
      const text = arr.slice(0,5).map((x,i)=>`${i+1}. *${x.title||'-'}*\n   ${x.url||x.link||''}\n   ${x.description||''}`).join('\n\n');
      return { ok: true, type: 'text', result: text || 'Tidak ada hasil.' };
    } catch (err) { return { ok: false, status: 500, message: err.message }; }
  },
};
