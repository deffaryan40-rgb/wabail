import axios from 'axios';
export default {
  id: 'info-bmkg', name: 'Gempa BMKG', category: 'Info',
  path: '/api/info/bmkg', method: 'GET',
  description: 'Info gempa terbaru dari BMKG',
  params: [],
  handler: async () => {
    try {
      const { data } = await axios.get('https://api.siputzx.my.id/api/info/bmkg', { timeout: 15000 });
      if (!data?.status) return { ok: false, status: 502, message: 'Gagal mengambil data BMKG.' };
      const d = data.data || {};
      const text = [
        `🌍 *Gempa Terbaru BMKG*`,
        d.Tanggal || d.tanggal ? `📅 Tanggal: ${d.Tanggal || d.tanggal}` : '',
        d.Jam || d.jam ? `⏰ Jam: ${d.Jam || d.jam} WIB` : '',
        d.Magnitude || d.magnitude ? `📊 Magnitudo: ${d.Magnitude || d.magnitude} SR` : '',
        d.Kedalaman || d.kedalaman ? `⬇️ Kedalaman: ${d.Kedalaman || d.kedalaman}` : '',
        d.Wilayah || d.wilayah ? `📍 Wilayah: ${d.Wilayah || d.wilayah}` : '',
        d.Potensi || d.potensi ? `⚠️ Potensi: ${d.Potensi || d.potensi}` : '',
        d.Dirasakan || d.dirasakan ? `🏠 Dirasakan: ${d.Dirasakan || d.dirasakan}` : '',
      ].filter(Boolean).join('\n');
      return { ok: true, type: 'text', result: text || JSON.stringify(d, null, 2) };
    } catch (err) { return { ok: false, status: 500, message: err.message }; }
  },
};
