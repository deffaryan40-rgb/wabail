import axios from 'axios';
export default {
  id: 'search-bimg', name: 'Search bimg', category: 'Search',
  path: '/api/s/bimg', method: 'GET',
  description: 'Cari konten di bimg',
  params: [{ name: 'query', required: true, example: 'kucing', description: 'Kata kunci pencarian' }],
  handler: async (req, getInput) => {
    const q = getInput(req, 'query');
    if (!q) return { ok: false, status: 400, message: "Parameter 'query' wajib diisi." };
    try {
      const { data } = await axios.get('https://api.siputzx.my.id/api/s/bimg', { params: { query: q }, timeout: 15000 });
      if (!data?.status) return { ok: false, status: 502, message: 'Gagal mencari.' };
      const imgUrl = Array.isArray(data.data) ? data.data[0]?.thumbnail || data.data[0]?.url || data.data[0] : data.data?.url;
      if (!imgUrl) return { ok: false, status: 502, message: 'Gambar tidak ditemukan.' };
      const caption = Array.isArray(data.data) ? data.data.slice(0,5).map((x,i)=>`${i+1}. ${x.link||x.url||''}`).join('\n') : '';
      return { ok: true, type: 'image', url: String(imgUrl), caption };
    } catch (err) { return { ok: false, status: 500, message: err.message }; }
  },
};
