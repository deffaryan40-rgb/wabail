import type * as Types from "./types/namespaced";
/** @module Constants */
import type PrivateChannel from "./structures/PrivateChannel";
import type TextChannel from "./structures/TextChannel";
import type VoiceChannel from "./structures/VoiceChannel";
import type GroupChannel from "./structures/GroupChannel";
import type CategoryChannel from "./structures/CategoryChannel";
import type AnnouncementChannel from "./structures/AnnouncementChannel";
import type AnnouncementThreadChannel from "./structures/AnnouncementThreadChannel";
import type PublicThreadChannel from "./structures/PublicThreadChannel";
import type PrivateThreadChannel from "./structures/PrivateThreadChannel";
import type StageChannel from "./structures/StageChannel";
import type ForumChannel from "./structures/ForumChannel";
import type MediaChannel from "./structures/MediaChannel";
export declare const GATEWAY_VERSION = 10;
export declare const REST_VERSION = 10;
export declare const BASE_URL = "https://discord.com";
export declare const API_URL = "https://discord.com/api/v10";
export declare const VERSION: any;
export declare const USER_AGENT: string;
export declare const MEDIA_PROXY_SIZES: number[];
export declare const RESTMethods: readonly ["GET", "POST", "PUT", "PATCH", "DELETE"];
export type RESTMethod = typeof RESTMethods[number];
export declare const ImageFormats: readonly ["jpg", "jpeg", "png", "webp", "gif"];
export type ImageFormat = typeof ImageFormats[number];
export declare enum WebhookTypes {
    INCOMING = 1,
    CHANNEL_FOLLOWER = 2,
    APPLICATION = 3
}
export declare enum PremiumTypes {
    NONE = 0,
    NITRO_CLASSIC = 1,
    NITRO = 2,
    NITRO_BASIC = 3
}
export declare enum UserFlags {
    STAFF = 1,
    PARTNER = 2,
    HYPESQUAD = 4,
    BUG_HUNTER_LEVEL_1 = 8,
    MFA_SMS = 16,
    PREMIUM_PROMO_DISMISSED = 32,
    HYPESQUAD_BRAVERY = 64,
    HYPESQUAD_BRILLIANCE = 128,
    HYPESQUAD_BALANCE = 256,
    EARLY_SUPPORTER = 512,
    PSEUDO_TEAM_USER = 1024,
    /** @deprecated Use `IS_HUBSPOT_CONTACT`. This will be removed in `1.15.0` */
    INTERNAL_APPLICATION = 2048,
    IS_HUBSPOT_CONTACT = 2048,
    /** @deprecated */
    SYSTEM = 4096,
    HAS_UNREAD_URGENT_MESSAGES = 8192,
    BUG_HUNTER_LEVEL_2 = 16384,
    UNDERAGE_DELETED = 32768,
    VERIFIED_BOT = 65536,
    VERIFIED_DEVELOPER = 131072,
    CERTIFIED_MODERATOR = 262144,
    BOT_HTTP_INTERACTIONS = 524288,
    SPAMMER = 1048576,
    /** @deprecated */
    DISABLE_PREMIUM = 2097152,
    /** @deprecated */
    ACTIVE_DEVELOPER = 4194304,
    PROVISIONAL_ACCOUNT = 8388608,
    HIGH_GLOBAL_RATE_LIMIT = 8589934592,
    DELETED = 17179869184,
    DISABLED_SUSPICIOUS_ACTIVITY = 34359738368,
    SELF_DELETED = 68719476736,
    /** @deprecated */
    PREMIUM_DISCRIMINATOR = 137438953472,
    USED_DESKTOP_CLIENT = 274877906944,
    USED_WEB_CLIENT = 549755813888,
    USED_MOBILE_CLIENT = 1099511627776,
    DISABLED = 2199023255552,
    VERIFIED_EMAIL = 8796093022208,
    QUARANTINED = 17592186044416,
    PREMIUM_ELIGIBLE_FOR_UNIQUE_USERNAME = 140737488355328,
    COLLABORATOR = 1125899906842624,
    RESTRICTED_COLLABORATOR = 2251799813685248
}
export declare enum ApplicationIntegrationTypes {
    GUILD_INSTALL = 0,
    USER_INSTALL = 1
}
export declare enum InteractionContextTypes {
    GUILD = 0,
    BOT_DM = 1,
    PRIVATE_CHANNEL = 2
}
export declare enum ApplicationFlags {
    EMBEDDED_RELEASED = 2,
    MANAGED_EMOJI = 4,
    EMBEDDED_IAP = 8,
    GROUP_DM_CREATE = 16,
    RPC_PRIVATE_BETA = 32,
    /** Indicates if an app uses the {@link https://discord.com/developers/docs/resources/auto-moderation | Auto Moderation API}. Applications must have at least 100 enabled auto moderation rules to get the badge. */
    APPLICATION_AUTO_MODERATION_RULE_CREATE_BADGE = 64,
    GAME_PROFILE_DISABLED = 128,
    /** @deprecated Use `PUBLIC_OAUTH2_CLIENT`. This will be removed in `1.15.0`. */
    ALLOW_ASSETS = 256,
    PUBLIC_OAUTH2_CLIENT = 256,
    /** @deprecated Use `CONTEXTLESS_ACTIVITY`. This will be removed in `1.15.0`. */
    ALLOW_ACTIVITY_ACTION_SPECTATE = 512,
    CONTEXTLESS_ACTIVITY = 512,
    /** @deprecated Use `SOCIAL_LAYER_INTEGRATION_LIMITED`. This will be removed in `1.15.0`. */
    ALLOW_ACTIVITY_ACTION_JOIN_REQUEST = 1024,
    SOCIAL_LAYER_INTEGRATION_LIMITED = 1024,
    /** @deprecated Use `CLOUD_GAMING_DEMO`. This will be removed in `1.15.0`. */
    RPC_HAS_CONNECTED_ACCOUNT = 2048,
    CLOUD_GAMING_DEMO = 2048,
    /** Intent required for bots in **100 or more servers** to receive {@link ClientEvents.presenceUpdate | `presenceUpdate`} events. */
    GATEWAY_PRESENCE = 4096,
    /** Intent required for bots in **under 100 servers** to receive {@link ClientEvents.presenceUpdate | `presenceUpdate`} events. */
    GATEWAY_PRESENCE_LIMITED = 8192,
    /** Intent required for bots in **100 or more servers** to receive member-related events like {@link ClientEvents.guildMemberAdd | `guildMemberAdd`}. */
    GATEWAY_GUILD_MEMBERS = 16384,
    /** Intent required for bots in **under 100 servers** to receive member-related events like {@link ClientEvents.guildMemberAdd | `guildMemberAdd`}. */
    GATEWAY_GUILD_MEMBERS_LIMITED = 32768,
    /** Indicates unusual growth of an app that prevents verification */
    VERIFICATION_PENDING_GUILD_LIMIT = 65536,
    /** Indicates if an app is embedded within the Discord client (currently unavailable publicly) */
    EMBEDDED = 131072,
    /** Intent required for bots in **100 or more servers** to receive {@link https://support-dev.discord.com/hc/en-us/articles/4404772028055 | message content}. */
    GATEWAY_MESSAGE_CONTENT = 262144,
    /** Intent required for bots in **under 100 servers** to receive {@link https://support-dev.discord.com/hc/en-us/articles/4404772028055 | message content}. */
    GATEWAY_MESSAGE_CONTENT_LIMITED = 524288,
    EMBEDDED_FIRST_PARTY = 1048576,
    APPLICATION_COMMAND_MIGRATED = 2097152,
    /** Indicates if an app has registered global {@link https://discord.com/developers/docs/interactions/application-commands | application commands}. */
    APPLICATION_COMMAND_BADGE = 8388608,
    ACTIVE = 16777216,
    ACTIVE_GRACE_PERIOD = 33554432,
    IFRAME_MODAL = 67108864,
    SOCIAL_LAYER_INTEGRATION = 134217728,
    PROMOTED = 268435456,
    PARTNER = 536870912,
    PARENT = 8589934592,
    DISABLE_RELATIONSHIP_ACCESS = 17179869184
}
export declare const GuildFeatures: readonly ["ACTIVITIES_ALPHA", "ACTIVITIES_EMPLOYEE", "ACTIVITIES_INTERNAL_DEV", "ANIMATED_BANNER", "ANIMATED_ICON", "APPLICATION_COMMAND_PERMISSIONS_V2", "AUTO_MODERATION", "AUTOMOD_TRIGGER_USER_PROFILE", "BANNER", "BOT_DEVELOPER_EARLY_ACCESS", "BURST_REACTIONS", "CHANNEL_HIGHLIGHTS_DISABLED", "CHANNEL_HIGHLIGHTS", "CHANNEL_ICON_EMOJIS_GENERATED", "CLYDE_DISABLED", "CLYDE_ENABLED", "CLYDE_EXPERIMENT_ENABLED", "COMMERCE", "COMMUNITY_CANARY", "COMMUNITY_EXP_LARGE_GATED", "COMMUNITY_EXP_LARGE_UNGATED", "COMMUNITY_EXP_MEDIUM", "COMMUNITY", "CREATOR_ACCEPTED_NEW_TERMS", "CREATOR_MONETIZABLE_DISABLED", "CREATOR_MONETIZABLE_PENDING_NEW_OWNER_ONBOARDING", "CREATOR_MONETIZABLE_PROVISIONAL", "CREATOR_MONETIZABLE_RESTRICTED", "CREATOR_MONETIZABLE_WHITEGLOVE", "CREATOR_MONETIZABLE", "CREATOR_STORE_PAGE", "DEVELOPER_SUPPORT_SERVER", "DISCOVERABLE_DISABLED", "DISCOVERABLE", "ENABLED_DISCOVERABLE_BEFORE", "ENABLED_MODERATION_EXPERIENCE_FOR_NON_COMMUNITY", "ENHANCED_ROLE_COLORS", "EXPOSED_TO_ACTIVITIES_WTP_EXPERIMENT", "FEATURABLE", "GUESTS_ENABLED", "GUILD_HOME_DEPRECATION_OVERRIDE", "GUILD_HOME_OVERRIDE", "GUILD_HOME_TEST", "GUILD_ONBOARDING_EVER_ENABLED", "GUILD_ONBOARDING_HAS_PROMPTS", "GUILD_ONBOARDING", "GUILD_ROLE_SUBSCRIPTION_TIER_TEMPLATE", "GUILD_SERVER_GUIDE", "GUILD_WEB_PAGE_VANITY_URL", "HAD_EARLY_ACTIVITIES_ACCESS", "HAS_DIRECTORY_ENTRY", "HUB", "INCREASED_THREAD_LIMIT", "INTERNAL_EMPLOYEE_ONLY", "INVITE_SPLASH", "INVITES_DISABLED", "LINKED_TO_HUB", "MARKETPLACES_CONNECTION_ROLES", "MEMBER_PROFILES", "MEMBER_SAFETY_PAGE_ROLLOUT", "MEMBER_VERIFICATION_GATE_ENABLED", "MONETIZATION_ENABLED", "MORE_EMOJI", "MORE_EMOJIS", "MORE_SOUNDBOARD", "MORE_STICKERS", "NEW_THREAD_PERMISSIONS", "NEWS", "NON_COMMUNITY_RAID_ALERTS", "PARTNERED", "PREVIEW_ENABLED", "PREVIOUSLY_DISCOVERABLE", "PRIVATE_THREADS", "PRODUCTS_AVAILABLE_FOR_PURCHASE", "RAID_ALERTS_DISABLED", "RAID_ALERTS_ENABLED", "ROLE_ICONS", "ROLE_SUBSCRIPTIONS_AVAILABLE_FOR_PURCHASE", "ROLE_SUBSCRIPTIONS_ENABLED", "SEVEN_DAY_THREAD_ARCHIVE", "SHARD", "SOUNDBOARD", "SUMMARIES_DISABLED_BY_USER", "SUMMARIES_ENABLED_BY_USER", "SUMMARIES_ENABLED_GA", "SUMMARIES_ENABLED", "SUMMARIES_OPT_OUT_EXPERIENCE", "SUMMARIES_PAUSED", "TEXT_IN_STAGE_ENABLED", "TEXT_IN_VOICE_ENABLED", "THREADS_ENABLED_TESTING", "THREADS_ENABLED", "THREE_DAY_THREAD_ARCHIVE", "TICKETED_EVENTS_ENABLED", "VANITY_URL", "VERIFIED", "VIP_REGIONS", "VOICE_IN_THREADS", "WELCOME_SCREEN_ENABLED"];
export type GuildFeature = typeof GuildFeatures[number];
export type MutableGuildFeatures = "COMMUNITY" | "DISCOVERABLE" | "INVITES_DISABLED" | "RAID_ALERTS_ENABLED";
export declare enum DefaultMessageNotificationLevels {
    ALL_MESSAGES = 0,
    ONLY_MENTIONS = 1,
    NO_MESSAGES = 2,
    NULL = 3
}
export declare enum ExplicitContentFilterLevels {
    DISABLED = 0,
    MEMBERS_WITHOUT_ROLES = 1,
    ALL_MEMBERS = 2
}
export declare enum MFALevels {
    NONE = 0,
    ELEVATED = 1
}
export declare enum VerificationLevels {
    NONE = 0,
    LOW = 1,
    MEDIUM = 2,
    HIGH = 3,
    VERY_HIGH = 4
}
export declare enum GuildNSFWLevels {
    DEFAULT = 0,
    EXPLICIT = 1,
    SAFE = 2,
    AGE_RESTRICTED = 3
}
export declare enum PremiumTiers {
    NONE = 0,
    TIER_1 = 1,
    TIER_2 = 2,
    TIER_3 = 3
}
export declare enum SystemChannelFlags {
    SUPPRESS_JOIN_NOTIFICATIONS = 1,
    SUPPRESS_PREMIUM_SUBSCRIPTIONS = 2,
    SUPPRESS_GUILD_REMINDER_NOTIFICATIONS = 4,
    SUPPRESS_JOIN_NOTIFICATION_REPLIES = 8,
    SUPPRESS_ROLE_SUBSCRIPTION_PURCHASE_NOTIFICATIONS = 16,
    SUPPRESS_ROLE_SUBSCRIPTION_PURCHASE_NOTIFICATION_REPLIES = 32,
    SUPPRESS_CHANNEL_PROMPT_DEADCHAT = 128
}
export declare enum StickerTypes {
    STANDARD = 1,
    GUILD = 2
}
export declare enum StickerFormatTypes {
    PNG = 1,
    APNG = 2,
    LOTTIE = 3,
    GIF = 4
}
export declare enum ChannelTypes {
    GUILD_TEXT = 0,
    DM = 1,
    GUILD_VOICE = 2,
    GROUP_DM = 3,
    GUILD_CATEGORY = 4,
    GUILD_ANNOUNCEMENT = 5,
    /** @deprecated Doesn't exist anymore. */
    GUILD_STORE = 6,
    /** @deprecated Doesn't exist anymore. */
    GUILD_LFG = 7,
    /** @deprecated Doesn't exist anymore. */
    LFG_GROUP_DM = 8,
    /** @deprecated Doesn't exist anymore. */
    THREAD_ALPHA = 9,
    ANNOUNCEMENT_THREAD = 10,
    PUBLIC_THREAD = 11,
    PRIVATE_THREAD = 12,
    GUILD_STAGE_VOICE = 13,
    GUILD_DIRECTORY = 14,
    GUILD_FORUM = 15,
    GUILD_MEDIA = 16
}
export declare const AnyChannelTypes: Array<ChannelTypes>;
export declare const NotImplementedChannelTypes: readonly [ChannelTypes.GUILD_STORE, ChannelTypes.GUILD_LFG, ChannelTypes.LFG_GROUP_DM, ChannelTypes.THREAD_ALPHA, ChannelTypes.GUILD_DIRECTORY];
export declare const ImplementedChannelTypes: (ChannelTypes.GUILD_TEXT | ChannelTypes.DM | ChannelTypes.GUILD_VOICE | ChannelTypes.GROUP_DM | ChannelTypes.GUILD_CATEGORY | ChannelTypes.GUILD_ANNOUNCEMENT | ChannelTypes.ANNOUNCEMENT_THREAD | ChannelTypes.PUBLIC_THREAD | ChannelTypes.PRIVATE_THREAD | ChannelTypes.GUILD_STAGE_VOICE | ChannelTypes.GUILD_FORUM | ChannelTypes.GUILD_MEDIA)[];
export declare const GuildChannelTypes: readonly [ChannelTypes.GUILD_TEXT, ChannelTypes.GUILD_VOICE, ChannelTypes.GUILD_CATEGORY, ChannelTypes.GUILD_ANNOUNCEMENT, ChannelTypes.ANNOUNCEMENT_THREAD, ChannelTypes.PUBLIC_THREAD, ChannelTypes.PRIVATE_THREAD, ChannelTypes.GUILD_STAGE_VOICE, ChannelTypes.GUILD_DIRECTORY, ChannelTypes.GUILD_FORUM, ChannelTypes.GUILD_MEDIA];
export declare const ThreadChannelTypes: readonly [ChannelTypes.ANNOUNCEMENT_THREAD, ChannelTypes.PUBLIC_THREAD, ChannelTypes.PRIVATE_THREAD];
export declare const GuildChannelsWithoutThreadsTypes: (ChannelTypes.GUILD_TEXT | ChannelTypes.GUILD_VOICE | ChannelTypes.GUILD_CATEGORY | ChannelTypes.GUILD_ANNOUNCEMENT | ChannelTypes.GUILD_STAGE_VOICE | ChannelTypes.GUILD_DIRECTORY | ChannelTypes.GUILD_FORUM | ChannelTypes.GUILD_MEDIA)[];
export declare const PrivateChannelTypes: readonly [ChannelTypes.DM, ChannelTypes.GROUP_DM];
export declare const EditableChannelTypes: (ChannelTypes.GUILD_TEXT | ChannelTypes.GUILD_VOICE | ChannelTypes.GROUP_DM | ChannelTypes.GUILD_CATEGORY | ChannelTypes.GUILD_ANNOUNCEMENT | ChannelTypes.ANNOUNCEMENT_THREAD | ChannelTypes.PUBLIC_THREAD | ChannelTypes.PRIVATE_THREAD | ChannelTypes.GUILD_STAGE_VOICE | ChannelTypes.GUILD_FORUM | ChannelTypes.GUILD_MEDIA)[];
export declare const TextableChannelTypes: (ChannelTypes.GUILD_TEXT | ChannelTypes.DM | ChannelTypes.GUILD_VOICE | ChannelTypes.GUILD_ANNOUNCEMENT | ChannelTypes.ANNOUNCEMENT_THREAD | ChannelTypes.PUBLIC_THREAD | ChannelTypes.PRIVATE_THREAD | ChannelTypes.GUILD_STAGE_VOICE)[];
export declare const TextableGuildChannelTypes: (ChannelTypes.GUILD_TEXT | ChannelTypes.GUILD_VOICE | ChannelTypes.GUILD_ANNOUNCEMENT | ChannelTypes.ANNOUNCEMENT_THREAD | ChannelTypes.PUBLIC_THREAD | ChannelTypes.PRIVATE_THREAD | ChannelTypes.GUILD_STAGE_VOICE)[];
export declare const TextableChannelsWithoutThreadsTypes: (ChannelTypes.GUILD_TEXT | ChannelTypes.DM | ChannelTypes.GUILD_VOICE | ChannelTypes.GUILD_ANNOUNCEMENT | ChannelTypes.GUILD_STAGE_VOICE)[];
export declare const TextableGuildChannelsWithoutThreadsTypes: (ChannelTypes.GUILD_TEXT | ChannelTypes.GUILD_VOICE | ChannelTypes.GUILD_ANNOUNCEMENT | ChannelTypes.GUILD_STAGE_VOICE)[];
export declare const VoiceChannelTypes: readonly [ChannelTypes.GUILD_VOICE, ChannelTypes.GUILD_STAGE_VOICE];
export declare const GuildInviteChannelTypes: readonly [ChannelTypes.GUILD_TEXT, ChannelTypes.GUILD_ANNOUNCEMENT, ChannelTypes.GUILD_VOICE, ChannelTypes.GUILD_STAGE_VOICE, ChannelTypes.GUILD_FORUM, ChannelTypes.GUILD_MEDIA];
export declare const DMInviteChannelTypes: readonly [ChannelTypes.GROUP_DM];
export declare const InviteChannelTypes: readonly [ChannelTypes.GUILD_TEXT, ChannelTypes.GUILD_ANNOUNCEMENT, ChannelTypes.GUILD_VOICE, ChannelTypes.GUILD_STAGE_VOICE, ChannelTypes.GUILD_FORUM, ChannelTypes.GUILD_MEDIA, ChannelTypes.GROUP_DM];
export declare const InteractionChannelTypes: readonly [...(ChannelTypes.GUILD_TEXT | ChannelTypes.DM | ChannelTypes.GUILD_VOICE | ChannelTypes.GUILD_ANNOUNCEMENT | ChannelTypes.ANNOUNCEMENT_THREAD | ChannelTypes.PUBLIC_THREAD | ChannelTypes.PRIVATE_THREAD | ChannelTypes.GUILD_STAGE_VOICE)[], ChannelTypes.GROUP_DM];
export declare const ThreadOnlyChannelTypes: readonly [ChannelTypes.GUILD_FORUM, ChannelTypes.GUILD_MEDIA];
export interface ChannelTypeMap {
    [ChannelTypes.GUILD_TEXT]: TextChannel;
    [ChannelTypes.DM]: PrivateChannel;
    [ChannelTypes.GUILD_VOICE]: VoiceChannel;
    [ChannelTypes.GROUP_DM]: GroupChannel;
    [ChannelTypes.GUILD_CATEGORY]: CategoryChannel;
    [ChannelTypes.GUILD_ANNOUNCEMENT]: AnnouncementChannel;
    [ChannelTypes.GUILD_STORE]: never;
    [ChannelTypes.GUILD_LFG]: never;
    [ChannelTypes.LFG_GROUP_DM]: never;
    [ChannelTypes.THREAD_ALPHA]: never;
    [ChannelTypes.ANNOUNCEMENT_THREAD]: AnnouncementThreadChannel;
    [ChannelTypes.PUBLIC_THREAD]: PublicThreadChannel;
    [ChannelTypes.PRIVATE_THREAD]: PrivateThreadChannel;
    [ChannelTypes.GUILD_STAGE_VOICE]: StageChannel;
    [ChannelTypes.GUILD_DIRECTORY]: never;
    [ChannelTypes.GUILD_FORUM]: ForumChannel;
    [ChannelTypes.GUILD_MEDIA]: MediaChannel;
}
export interface RawChannelTypeMap {
    [ChannelTypes.GUILD_TEXT]: Types.Channels.RawTextChannel;
    [ChannelTypes.DM]: Types.Channels.RawPrivateChannel;
    [ChannelTypes.GUILD_VOICE]: Types.Channels.RawVoiceChannel;
    [ChannelTypes.GROUP_DM]: Types.Channels.RawGroupChannel;
    [ChannelTypes.GUILD_CATEGORY]: Types.Channels.RawCategoryChannel;
    [ChannelTypes.GUILD_ANNOUNCEMENT]: Types.Channels.RawAnnouncementChannel;
    [ChannelTypes.GUILD_STORE]: never;
    [ChannelTypes.GUILD_LFG]: never;
    [ChannelTypes.LFG_GROUP_DM]: never;
    [ChannelTypes.THREAD_ALPHA]: never;
    [ChannelTypes.ANNOUNCEMENT_THREAD]: Types.Channels.RawAnnouncementThreadChannel;
    [ChannelTypes.PUBLIC_THREAD]: Types.Channels.RawPublicThreadChannel;
    [ChannelTypes.PRIVATE_THREAD]: Types.Channels.RawPrivateThreadChannel;
    [ChannelTypes.GUILD_STAGE_VOICE]: Types.Channels.RawStageChannel;
    [ChannelTypes.GUILD_DIRECTORY]: never;
    [ChannelTypes.GUILD_FORUM]: Types.Channels.RawForumChannel;
    [ChannelTypes.GUILD_MEDIA]: Types.Channels.RawMediaChannel;
}
export interface JSONChannelTypeMap {
    [ChannelTypes.GUILD_TEXT]: Types.JSON.JSONTextChannel;
    [ChannelTypes.DM]: Types.JSON.JSONPrivateChannel;
    [ChannelTypes.GUILD_VOICE]: Types.JSON.JSONVoiceChannel;
    [ChannelTypes.GROUP_DM]: Types.JSON.JSONGroupChannel;
    [ChannelTypes.GUILD_CATEGORY]: Types.JSON.JSONCategoryChannel;
    [ChannelTypes.GUILD_ANNOUNCEMENT]: Types.JSON.JSONAnnouncementChannel;
    [ChannelTypes.ANNOUNCEMENT_THREAD]: Types.JSON.JSONAnnouncementThreadChannel;
    [ChannelTypes.PUBLIC_THREAD]: Types.JSON.JSONPublicThreadChannel;
    [ChannelTypes.PRIVATE_THREAD]: Types.JSON.JSONPrivateThreadChannel;
    [ChannelTypes.GUILD_STAGE_VOICE]: Types.JSON.JSONStageChannel;
    [ChannelTypes.GUILD_DIRECTORY]: never;
    [ChannelTypes.GUILD_FORUM]: Types.JSON.JSONForumChannel;
    [ChannelTypes.GUILD_MEDIA]: Types.JSON.JSONMediaChannel;
}
export declare enum OverwriteTypes {
    ROLE = 0,
    MEMBER = 1
}
export declare enum VideoQualityModes {
    AUTO = 1,
    FULL = 2
}
export declare const ThreadAutoArchiveDurations: readonly [60, 1440, 4320, 10080];
export type ThreadAutoArchiveDuration = typeof ThreadAutoArchiveDurations[number];
export declare enum ConnectionVisibilityTypes {
    NONE = 0,
    EVERYONE = 1
}
export declare const ConnectionServices: readonly ["battlenet", "bluesky", "crunchyroll", "domain", "ebay", "epicgames", "facebook", "github", "instagram", "leagueoflegends", "mastodon", "paypal", "playstation", "reddit", "riotgames", "skype", "spotify", "steam", "tiktok", "twitch", "twitter_legacy", "twitter", "xbox", "youtube"];
export type ConnectionService = typeof ConnectionServices[number];
export declare const IntegrationTypes: readonly ["twitch", "youtube", "discord", "guild_subscription"];
export type IntegrationType = typeof IntegrationTypes[number];
export declare enum IntegrationExpireBehaviors {
    REMOVE_ROLE = 0,
    KICK = 1
}
export declare namespace Permissions {
    const CREATE_INSTANT_INVITE = 1n;
    const KICK_MEMBERS = 2n;
    const BAN_MEMBERS = 4n;
    const ADMINISTRATOR = 8n;
    const MANAGE_CHANNELS = 16n;
    const MANAGE_GUILD = 32n;
    const ADD_REACTIONS = 64n;
    const VIEW_AUDIT_LOG = 128n;
    const PRIORITY_SPEAKER = 256n;
    const STREAM = 512n;
    const VIEW_CHANNEL = 1024n;
    const SEND_MESSAGES = 2048n;
    const SEND_TTS_MESSAGES = 4096n;
    const MANAGE_MESSAGES = 8192n;
    const EMBED_LINKS = 16384n;
    const ATTACH_FILES = 32768n;
    const READ_MESSAGE_HISTORY = 65536n;
    const MENTION_EVERYONE = 131072n;
    const USE_EXTERNAL_EMOJIS = 262144n;
    const VIEW_GUILD_INSIGHTS = 524288n;
    const CONNECT = 1048576n;
    const SPEAK = 2097152n;
    const MUTE_MEMBERS = 4194304n;
    const DEAFEN_MEMBERS = 8388608n;
    const MOVE_MEMBERS = 16777216n;
    const USE_VAD = 33554432n;
    const CHANGE_NICKNAME = 67108864n;
    const MANAGE_NICKNAMES = 134217728n;
    const MANAGE_ROLES = 268435456n;
    const MANAGE_WEBHOOKS = 536870912n;
    const MANAGE_GUILD_EXPRESSIONS = 1073741824n;
    const USE_APPLICATION_COMMANDS = 2147483648n;
    const REQUEST_TO_SPEAK = 4294967296n;
    const MANAGE_EVENTS = 8589934592n;
    const MANAGE_THREADS = 17179869184n;
    const CREATE_PUBLIC_THREADS = 34359738368n;
    const CREATE_PRIVATE_THREADS = 68719476736n;
    const USE_EXTERNAL_STICKERS = 137438953472n;
    const SEND_MESSAGES_IN_THREADS = 274877906944n;
    const USE_EMBEDDED_ACTIVITIES = 549755813888n;
    const MODERATE_MEMBERS = 1099511627776n;
    const VIEW_CREATOR_MONETIZATION_ANALYTICS = 2199023255552n;
    const USE_SOUNDBOARD = 4398046511104n;
    const CREATE_GUILD_EXPRESSIONS = 8796093022208n;
    const CREATE_EVENTS = 17592186044416n;
    const USE_EXTERNAL_SOUNDS = 35184372088832n;
    const SEND_VOICE_MESSAGES = 70368744177664n;
    const USE_CLYDE_AI = 140737488355328n;
    const SET_VOICE_CHANNEL_STATUS = 281474976710656n;
    const SEND_POLLS = 562949953421312n;
    const USE_EXTERNAL_APPS = 1125899906842624n;
    const PIN_MESSAGES = 2251799813685248n;
    const BYPASS_SLOWMODE = 4503599627370496n;
}
export declare const PermissionValueToName: Types.Shared.ReverseMap<Types.Shared.StringMap<typeof Permissions>>;
export declare const AllPermissions: bigint;
export declare const TextPermissions: readonly [1n, 16n, 64n, 1024n, 2048n, 4096n, 8192n, 16384n, 32768n, 65536n, 131072n, 262144n, 268435456n, 536870912n, 2147483648n, 17179869184n, 34359738368n, 68719476736n, 137438953472n, 274877906944n, 70368744177664n, 140737488355328n, 562949953421312n, 1125899906842624n, 2251799813685248n, 4503599627370496n];
export declare const AllTextPermissions: bigint;
export declare const AllTextPermissionNames: ("CREATE_INSTANT_INVITE" | "MANAGE_CHANNELS" | "ADD_REACTIONS" | "VIEW_CHANNEL" | "SEND_MESSAGES" | "SEND_TTS_MESSAGES" | "MANAGE_MESSAGES" | "EMBED_LINKS" | "ATTACH_FILES" | "READ_MESSAGE_HISTORY" | "MENTION_EVERYONE" | "USE_EXTERNAL_EMOJIS" | "MANAGE_ROLES" | "MANAGE_WEBHOOKS" | "USE_APPLICATION_COMMANDS" | "MANAGE_THREADS" | "CREATE_PUBLIC_THREADS" | "CREATE_PRIVATE_THREADS" | "USE_EXTERNAL_STICKERS" | "SEND_MESSAGES_IN_THREADS" | "SEND_VOICE_MESSAGES" | "USE_CLYDE_AI" | "SEND_POLLS" | "USE_EXTERNAL_APPS" | "PIN_MESSAGES" | "BYPASS_SLOWMODE")[];
export declare const VoicePermissions: readonly [1n, 16n, 64n, 256n, 512n, 1024n, 2048n, 4096n, 8192n, 16384n, 32768n, 65536n, 131072n, 262144n, 1048576n, 2097152n, 4194304n, 8388608n, 16777216n, 33554432n, 268435456n, 536870912n, 2147483648n, 8589934592n, 137438953472n, 549755813888n, 4398046511104n, 35184372088832n, 70368744177664n, 140737488355328n, 281474976710656n, 562949953421312n, 1125899906842624n, 4503599627370496n];
export declare const AllVoicePermissions: bigint;
export declare const AllVoicePermissionNames: ("CREATE_INSTANT_INVITE" | "MANAGE_CHANNELS" | "ADD_REACTIONS" | "PRIORITY_SPEAKER" | "STREAM" | "VIEW_CHANNEL" | "SEND_MESSAGES" | "SEND_TTS_MESSAGES" | "MANAGE_MESSAGES" | "EMBED_LINKS" | "ATTACH_FILES" | "READ_MESSAGE_HISTORY" | "MENTION_EVERYONE" | "USE_EXTERNAL_EMOJIS" | "CONNECT" | "SPEAK" | "MUTE_MEMBERS" | "DEAFEN_MEMBERS" | "MOVE_MEMBERS" | "USE_VAD" | "MANAGE_ROLES" | "MANAGE_WEBHOOKS" | "USE_APPLICATION_COMMANDS" | "MANAGE_EVENTS" | "USE_EXTERNAL_STICKERS" | "USE_EMBEDDED_ACTIVITIES" | "USE_SOUNDBOARD" | "USE_EXTERNAL_SOUNDS" | "SEND_VOICE_MESSAGES" | "USE_CLYDE_AI" | "SET_VOICE_CHANNEL_STATUS" | "SEND_POLLS" | "USE_EXTERNAL_APPS" | "BYPASS_SLOWMODE")[];
export declare const StagePermissions: readonly [1n, 16n, 64n, 512n, 1024n, 2048n, 4096n, 8192n, 16384n, 32768n, 65536n, 131072n, 262144n, 1048576n, 4194304n, 16777216n, 268435456n, 536870912n, 2147483648n, 4294967296n, 8589934592n, 137438953472n, 70368744177664n, 140737488355328n, 562949953421312n, 1125899906842624n, 4503599627370496n];
export declare const AllStagePermissions: bigint;
export declare const AllStagePermissionNames: ("CREATE_INSTANT_INVITE" | "MANAGE_CHANNELS" | "ADD_REACTIONS" | "STREAM" | "VIEW_CHANNEL" | "SEND_MESSAGES" | "SEND_TTS_MESSAGES" | "MANAGE_MESSAGES" | "EMBED_LINKS" | "ATTACH_FILES" | "READ_MESSAGE_HISTORY" | "MENTION_EVERYONE" | "USE_EXTERNAL_EMOJIS" | "CONNECT" | "MUTE_MEMBERS" | "MOVE_MEMBERS" | "MANAGE_ROLES" | "MANAGE_WEBHOOKS" | "USE_APPLICATION_COMMANDS" | "REQUEST_TO_SPEAK" | "MANAGE_EVENTS" | "USE_EXTERNAL_STICKERS" | "SEND_VOICE_MESSAGES" | "USE_CLYDE_AI" | "SEND_POLLS" | "USE_EXTERNAL_APPS" | "BYPASS_SLOWMODE")[];
/** These permissions require the bot owner's account to have 2FA enabled in guilds where 2FA is a requirement. */
export declare const ModeratorPermissions: readonly [2n, 4n, 8n, 16n, 32n, 8192n, 268435456n, 536870912n, 1073741824n, 17179869184n, 1099511627776n, 2199023255552n];
export declare const AllModeratorPermissions: bigint;
export declare const AllModeratorPermissionNames: ("KICK_MEMBERS" | "BAN_MEMBERS" | "ADMINISTRATOR" | "MANAGE_CHANNELS" | "MANAGE_GUILD" | "MANAGE_MESSAGES" | "MANAGE_ROLES" | "MANAGE_WEBHOOKS" | "MANAGE_GUILD_EXPRESSIONS" | "MANAGE_THREADS" | "MODERATE_MEMBERS" | "VIEW_CREATOR_MONETIZATION_ANALYTICS")[];
export declare const PermissionNames: Array<PermissionName>;
export type PermissionName = keyof typeof Permissions;
export declare enum ChannelFlags {
    GUILD_FEED_REMOVED = 1,
    /** For threads, if this thread is pinned in a forum channel. */
    PINNED = 2,
    ACTIVE_CHANNELS_REMOVED = 4,
    /** For forums, if tags are required when creating threads. */
    REQUIRE_TAG = 16,
    IS_SPAM = 32,
    IS_GUILD_RESOURCE_CHANNEL = 128,
    CLYDE_AI = 256,
    IS_SCHEDULED_FOR_DELETION = 512,
    IS_MEDIA_CHANNEL = 1024,
    SUMMARIES_DISABLED = 2048,
    APPLICATION_SHELF_CONSENT = 4096,
    IS_ROLE_SUBSCRIPTION_TEMPLATE_PREVIEW_CHANNEL = 8192,
    IS_BROADCASTING = 16384,
    /** For media channls, hides the embedded media download options. */
    HIDE_MEDIA_DOWNLOAD_OPTIONS = 32768,
    IS_JOIN_REQUEST_INTERVIEW_CHANNEL = 65536
}
export declare enum SortOrderTypes {
    /** Sort forum threads by activity. */
    LATEST_ACTIVITY = 0,
    /** Sort forum threads by creation time (from most recent to oldest). */
    CREATION_DATE = 1
}
export declare enum ForumLayoutTypes {
    /** A preferred forum layout hasn't been set by a server admin. */
    DEFAULT = 0,
    /** List View: display forum posts in a text-focused list. */
    LIST = 1,
    /** Gallery View: display forum posts in a media-focused gallery. */
    GRID = 2
}
export declare enum TeamMembershipState {
    INVITED = 1,
    ACCEPTED = 2
}
export declare enum OAuthScopes {
    /** allows your app to fetch data from a user's "Now Playing/Recently Played" list - requires Discord approval */
    ACTIVITIES_READ = "activities.read",
    /** allows your app to update a user's activity - requires Discord approval (NOT REQUIRED FOR [GAMESDK ACTIVITY MANAGER](https://discord.com/developers/docs/game-sdk/activities)) */
    ACTIVITIES_WRITE = "activities.write",
    /** allows your app to read build data for a user's applications */
    APPLICATIONS_BUILDS_READ = "applications.builds.read",
    /** allows your app to upload/update builds for a user's applications - requires Discord approval */
    APPLICATIONS_BUILDS_UPLOAD = "applications.builds.upload",
    /** allows your app to use [commands](https://discord.com/developers/docs/interactions/application-commands) in a guild */
    APPLICATIONS_COMMANDS = "applications.commands",
    APPLICATIONS_COMMANDS_PERMISSIONS_UPDATE = "applications.commands.permissions.update",
    /** allows your app to update its [commands](https://discord.com/developers/docs/interactions/application-commands) using a Bearer token - [client credentials grant](https://discord.com/developers/docs/topics/oauth2#client-credentials-grant) only */
    APPLICATIONS_COMMANDS_UPDATE = "applications.commands.update",
    /** allows your app to read entitlements for a user's applications */
    APPLICATIONS_ENTITLEMENTS = "applications.entitlements",
    /** allows your app to read and update store data (SKUs, store listings, achievements, etc.) for a user's applications */
    APPLICATIONS_STORE_UPDATE = "applications.store.update",
    /** for oauth2 bots, this puts the bot in the user's selected guild by default */
    BOT = "bot",
    /** allows [/users/@me/connections](https://discord.com/developers/docs/resources/user#get-user-connections) to return linked third-party accounts */
    CONNECTIONS = "connections",
    /** allows your app to see information about the user's DMs and group DMs - requires Discord approval */
    DM_CHANNELS_READ = "dm_channels.read",
    /** enables [/users/@me](https://discord.com/developers/docs/resources/user#get-current-user) to return an `email` */
    EMAIL = "email",
    /** allows your app to [join users to a group dm](https://discord.com/developers/docs/resources/channel#group-dm-add-recipient) */
    GDM_JOIN = "gdm.join",
    /** allows [/users/@me/guilds](https://discord.com/developers/docs/resources/user#get-current-user-guilds) to return basic information about all of a user's guilds */
    GUILDS = "guilds",
    /** allows [/guilds/\{guild.id\}/members/\{user.id\}](https://discord.com/developers/docs/resources/guild#add-guild-member) to be used for joining users to a guild */
    GUILDS_JOIN = "guilds.join",
    /** allows [/users/@me/guilds/\{guild.id\}/member](https://discord.com/developers/docs/resources/user#get-current-user-guild-member) to return a user's member information in a guild */
    GUILDS_MEMBERS_READ = "guilds.members.read",
    /** allows [/users/@me](https://discord.com/developers/docs/resources/user#get-current-user) without `email` */
    IDENTIFY = "identify",
    /** for local rpc server api access, this allows you to read messages from all client channels (otherwise restricted to channels/guilds your app creates) */
    MESSAGES_READ = "messages.read",
    /** allows your app to know a user's friends and implicit relationships */
    RELATIONSHIPS_READ = "relationships.read",
    /** allows your app to update a user's connection and metadata for the app */
    ROLE_CONNECTIONS_WRITE = "role_connections.write",
    /** for local rpc server access, this allows you to control a user's local Discord client - requires Discord approval */
    RPC = "rpc",
    /** for local rpc server access, this allows you to receive notifications pushed out to the user - requires Discord approval */
    RPC_ACTIVITIES_READ = "rpc.activities.read",
    /** for local rpc server access, this allows you to update a user's activity - requires Discord approval */
    RPC_ACTIVITIES_WRITE = "rpc.activities.write",
    /** for local rpc server access, this allows you to receive notifications pushed out to the user - requires Discord approval */
    RPC_NOTIFICATIONS_READ = "rpc.notifications.read",
    /** for local rpc server access, this allows you to read a user's voice settings and listen for voice events - requires Discord approval */
    RPC_VOICE_READ = "rpc.voice.read",
    /** for local rpc server access, this allows you to update a user's voice settings - requires Discord approval */
    RPC_VOICE_WRITE = "rpc.voice.write",
    /** allows your app to connect to voice on user's behalf and see all the voice members - requires Discord approval */
    VOICE = "voice",
    /** This generates a webhook that is returned in the oauth token response for authorization code grants. */
    WEBHOOK_INCOMING = "webhook.incoming"
}
export declare enum ComponentTypes {
    ACTION_ROW = 1,
    BUTTON = 2,
    STRING_SELECT = 3,
    TEXT_INPUT = 4,
    USER_SELECT = 5,
    ROLE_SELECT = 6,
    MENTIONABLE_SELECT = 7,
    CHANNEL_SELECT = 8,
    SECTION = 9,
    TEXT_DISPLAY = 10,
    THUMBNAIL = 11,
    MEDIA_GALLERY = 12,
    FILE = 13,
    SEPARATOR = 14,
    CONTENT_INVENTORY_ENTRY = 16,
    CONTAINER = 17,
    LABEL = 18,
    FILE_UPLOAD = 19,
    RADIO_GROUP = 21,
    CHECKBOX_GROUP = 22,
    CHECKBOX = 23
}
export type SelectMenuNonResolvedTypes = ComponentTypes.STRING_SELECT;
export type SelectMenuResolvedTypes = ComponentTypes.USER_SELECT | ComponentTypes.ROLE_SELECT | ComponentTypes.MENTIONABLE_SELECT | ComponentTypes.CHANNEL_SELECT;
export type SelectMenuTypes = SelectMenuNonResolvedTypes | SelectMenuResolvedTypes;
export type MessageComponentTypes = ComponentTypes.BUTTON | SelectMenuTypes;
export type ModalComponentTypes = ComponentTypes.CHECKBOX | ComponentTypes.CHECKBOX_GROUP | ComponentTypes.RADIO_GROUP | ComponentTypes.TEXT_INPUT | SelectMenuTypes | ComponentTypes.FILE_UPLOAD | ComponentTypes.LABEL | ComponentTypes.TEXT_DISPLAY | ComponentTypes.SECTION;
export declare enum ButtonStyles {
    PRIMARY = 1,
    SECONDARY = 2,
    SUCCESS = 3,
    DANGER = 4,
    LINK = 5,
    PREMIUM = 6
}
export declare enum TextInputStyles {
    SHORT = 1,
    PARAGRAPH = 2
}
export declare enum MessageFlags {
    CROSSPOSTED = 1,
    IS_CROSSPOST = 2,
    SUPPRESS_EMBEDS = 4,
    SOURCE_MESSAGE_DELETED = 8,
    URGENT = 16,
    HAS_THREAD = 32,
    EPHEMERAL = 64,
    LOADING = 128,
    FAILED_TO_MENTION_SOME_ROLES_IN_THREAD = 256,
    SHOULD_SHOW_LINK_NOT_DISCORD_WARNING = 1024,
    SUPPRESS_NOTIFICATIONS = 4096,
    IS_VOICE_MESSAGE = 8192,
    HAS_SNAPSHOT = 16384,
    IS_COMPONENTS_V2 = 32768
}
export declare enum MessageTypes {
    DEFAULT = 0,
    RECIPIENT_ADD = 1,
    RECIPIENT_REMOVE = 2,
    CALL = 3,
    CHANNEL_NAME_CHANGE = 4,
    CHANNEL_ICON_CHANGE = 5,
    CHANNEL_PINNED_MESSAGE = 6,
    USER_JOIN = 7,
    GUILD_BOOST = 8,
    GUILD_BOOST_TIER_1 = 9,
    GUILD_BOOST_TIER_2 = 10,
    GUILD_BOOST_TIER_3 = 11,
    CHANNEL_FOLLOW_ADD = 12,
    GUILD_STREAM = 13,
    GUILD_DISCOVERY_DISQUALIFIED = 14,
    GUILD_DISCOVERY_REQUALIFIED = 15,
    GUILD_DISCOVERY_GRACE_PERIOD_INITIAL_WARNING = 16,
    GUILD_DISCOVERY_GRACE_PERIOD_FINAL_WARNING = 17,
    THREAD_CREATED = 18,
    REPLY = 19,
    CHAT_INPUT_COMMAND = 20,
    THREAD_STARTER_MESSAGE = 21,
    GUILD_INVITE_REMINDER = 22,
    CONTEXT_MENU_COMMAND = 23,
    AUTO_MODERATION_ACTION = 24,
    ROLE_SUBSCRIPTION_PURCHASE = 25,
    INTERACTION_PREMIUM_UPSELL = 26,
    STAGE_START = 27,
    STAGE_END = 28,
    STAGE_SPEAKER = 29,
    STAGE_RAISE_HAND = 30,
    STAGE_TOPIC_CHANGE = 31,
    GUILD_APPLICATION_PREMIUM_SUBSCRIPTION = 32,
    PRIVATE_CHANNEL_INTEGRATION_ADDED = 33,
    PRIVATE_CHANNEL_INTEGRATION_REMOVED = 34,
    PREMIUM_REFERRAL = 35,
    GUILD_INCIDENT_ALERT_MODE_ENABLED = 36,
    GUILD_INCIDENT_ALERT_MODE_DISABLED = 37,
    GUILD_INCIDENT_REPORT_RAID = 38,
    GUILD_INCIDENT_REPORT_FALSE_ALARM = 39,
    GUILD_DEADCHAT_REVIVE_PROMPT = 40,
    CUSTOM_GIFT = 41,
    GUILD_GAMING_STATS_PROMPT = 42,
    POLL = 43,
    PURCHASE_NOTIFICATION = 44,
    VOICE_HANGOUT_INVITE = 45,
    POLL_RESULT = 46,
    CHANGELOG = 47,
    NITRO_NOTIFICATION = 48
}
/** Messages of these types cannot be deleted. */
export declare const UndeletableMessageTypes: readonly [MessageTypes.RECIPIENT_ADD, MessageTypes.RECIPIENT_REMOVE, MessageTypes.CALL, MessageTypes.CHANNEL_NAME_CHANGE, MessageTypes.CHANNEL_ICON_CHANGE, MessageTypes.THREAD_STARTER_MESSAGE];
export declare enum MessageActivityTypes {
    JOIN = 1,
    SPECTATE = 2,
    LISTEN = 3,
    WATCH = 4,
    JOIN_REQUEST = 5
}
export declare enum InteractionTypes {
    PING = 1,
    APPLICATION_COMMAND = 2,
    MESSAGE_COMPONENT = 3,
    APPLICATION_COMMAND_AUTOCOMPLETE = 4,
    MODAL_SUBMIT = 5
}
export declare enum InviteTypes {
    GUILD = 0,
    GROUP_DM = 1,
    FRIEND = 2
}
export declare enum InviteTargetTypes {
    STREAM = 1,
    EMBEDDED_APPLICATION = 2,
    ROLE_SUBSCRIPTIONS_PURCHASE = 3
}
export declare enum GuildScheduledEventPrivacyLevels {
    GUILD_ONLY = 2
}
export declare enum GuildScheduledEventStatuses {
    SCHEDULED = 1,
    ACTIVE = 2,
    COMPLETED = 3,
    CANCELED = 4
}
export declare enum GuildScheduledEventEntityTypes {
    STAGE_INSTANCE = 1,
    VOICE = 2,
    EXTERNAL = 3
}
export declare enum StageInstancePrivacyLevels {
    /** @deprecated */
    PUBLIC = 1,
    GUILD_ONLY = 2
}
export declare enum AutoModerationEventTypes {
    MESSAGE_SEND = 1,
    MEMBER_UPDATE = 2
}
export declare enum AutoModerationTriggerTypes {
    KEYWORD = 1,
    SPAM = 3,
    KEYWORD_PRESET = 4,
    MENTION_SPAM = 5,
    MEMBER_PROFILE = 6
}
export declare enum AutoModerationKeywordPresetTypes {
    PROFANITY = 1,
    SEXUAL_CONTENT = 2,
    SLURS = 3
}
export declare enum AutoModerationActionTypes {
    BLOCK_MESSAGE = 1,
    SEND_ALERT_MESSAGE = 2,
    TIMEOUT = 3,
    BLOCK_MEMBER_INTERACTION = 4
}
export declare enum AuditLogActionTypes {
    GUILD_UPDATE = 1,
    CHANNEL_CREATE = 10,
    CHANNEL_UPDATE = 11,
    CHANNEL_DELETE = 12,
    CHANNEL_OVERWRITE_CREATE = 13,
    CHANNEL_OVERWRITE_UPDATE = 14,
    CHANNEL_OVERWRITE_DELETE = 15,
    MEMBER_KICK = 20,
    MEMBER_PRUNE = 21,
    MEMBER_BAN_ADD = 22,
    MEMBER_BAN_REMOVE = 23,
    MEMBER_UPDATE = 24,
    MEMBER_ROLE_UPDATE = 25,
    MEMBER_MOVE = 26,
    MEMBER_DISCONNECT = 27,
    BOT_ADD = 28,
    ROLE_CREATE = 30,
    ROLE_UPDATE = 31,
    ROLE_DELETE = 32,
    INVITE_CREATE = 40,
    INVITE_UPDATE = 41,
    INVITE_DELETE = 42,
    WEBHOOK_CREATE = 50,
    WEBHOOK_UPDATE = 51,
    WEBHOOK_DELETE = 52,
    EMOJI_CREATE = 60,
    EMOJI_UPDATE = 61,
    EMOJI_DELETE = 62,
    MESSAGE_DELETE = 72,
    MESSAGE_BULK_DELETE = 73,
    MESSAGE_PIN = 74,
    MESSAGE_UNPIN = 75,
    INTEGRATION_CREATE = 80,
    INTEGRATION_UPDATE = 81,
    INTEGRATION_DELETE = 82,
    STAGE_INSTANCE_CREATE = 83,
    STAGE_INSTANCE_UPDATE = 84,
    STAGE_INSTANCE_DELETE = 85,
    STICKER_CREATE = 90,
    STICKER_UPDATE = 91,
    STICKER_DELETE = 92,
    GUILD_SCHEDULED_EVENT_CREATE = 100,
    GUILD_SCHEDULED_EVENT_UPDATE = 101,
    GUILD_SCHEDULED_EVENT_DELETE = 102,
    THREAD_CREATE = 110,
    THREAD_UPDATE = 111,
    THREAD_DELETE = 112,
    APPLICATION_COMMAND_PERMISSION_UPDATE = 121,
    SOUNDBOARD_SOUND_CREATE = 130,
    SOUNDBOARD_SOUND_UPDATE = 131,
    SOUNDBOARD_SOUND_DELETE = 132,
    AUTO_MODERATION_RULE_CREATE = 140,
    AUTO_MODERATION_RULE_UPDATE = 141,
    AUTO_MODERATION_RULE_DELETE = 142,
    AUTO_MODERATION_BLOCK_MESSAGE = 143,
    AUTO_MODERATION_FLAG_TO_CHANNEL = 144,
    AUTO_MODERATION_USER_COMMUNICATION_DISABLED = 145,
    AUTO_MODERATION_QUARANTINE_USER = 146,
    CREATOR_MONETIZATION_REQUEST_CREATED = 150,
    CREATOR_MONETIZATION_TERMS_ACCEPTED = 151,
    ROLE_PROMPT_CREATE = 160,
    ROLE_PROMPT_UPDATE = 161,
    ROLE_PROMPT_DELETE = 162,
    ONBOARDING_PROMPT_CREATE = 163,
    ONBOARDING_PROMPT_UPDATE = 164,
    ONBOARDING_PROMPT_DELETE = 165,
    ONBOARDING_CREATE = 166,
    ONBOARDING_UPDATE = 167,
    GUILD_HOME_FEATURE_ITEM = 171,
    GUILD_HOME_REMOVE_ITEM = 172,
    /** @deprecated */
    HARMFUL_LINKS_BLOCKED_MESSAGE = 180,
    HOME_SETTINGS_CREATE = 190,
    HOME_SETTINGS_UPDATE = 191,
    VOICE_CHANNEL_STATUS_CREATE = 192,
    VOICE_CHANNEL_STATUS_DELETE = 193,
    /** @deprecated */
    CLYDE_AI_PROFILE_UPDATE = 194,
    GUILD_SCHEDULED_EVENT_EXCEPTION_CREATE = 200,
    GUILD_SCHEDULED_EVENT_EXCEPTION_UPDATE = 201,
    GUILD_SCHEDULED_EVENT_EXCEPTION_DELETE = 202,
    GUILD_MEMBER_VERIFICATION_UPDATE = 210,
    GUILD_PROFILE_UPDATE = 211,
    PIN_PERMISSION_MIGRATION_COMPLETE = 212,
    BYPASS_SLOWMODE_PERMISSION_MIGRATION_COM = 213
}
export declare enum ApplicationCommandTypes {
    CHAT_INPUT = 1,
    USER = 2,
    MESSAGE = 3,
    PRIMARY_ENTRY_POINT = 4
}
export declare enum ApplicationCommandOptionTypes {
    SUB_COMMAND = 1,
    SUB_COMMAND_GROUP = 2,
    STRING = 3,
    INTEGER = 4,
    BOOLEAN = 5,
    USER = 6,
    CHANNEL = 7,
    ROLE = 8,
    MENTIONABLE = 9,
    NUMBER = 10,
    ATTACHMENT = 11
}
export declare enum ApplicationCommandPermissionTypes {
    ROLE = 1,
    USER = 2,
    CHANNEL = 3
}
export declare enum InteractionResponseTypes {
    PONG = 1,
    CHANNEL_MESSAGE_WITH_SOURCE = 4,
    DEFERRED_CHANNEL_MESSAGE_WITH_SOURCE = 5,
    DEFERRED_UPDATE_MESSAGE = 6,
    UPDATE_MESSAGE = 7,
    APPLICATION_COMMAND_AUTOCOMPLETE_RESULT = 8,
    MODAL = 9,
    /** @deprecated */
    PREMIUM_REQUIRED = 10,
    LAUNCH_ACTIVITY = 12
}
export declare enum EntryPointCommandHandlerTypes {
    APP_HANDLER = 1,
    DISCORD_LAUNCH_ACTIVITY = 2
}
export declare enum Intents {
    GUILDS = 1,
    GUILD_MEMBERS = 2,
    GUILD_MODERATION = 4,
    /** @deprecated */
    GUILD_EMOJIS_AND_STICKERS = 8,
    GUILD_EXPRESSIONS = 8,
    GUILD_INTEGRATIONS = 16,
    GUILD_WEBHOOKS = 32,
    GUILD_INVITES = 64,
    GUILD_VOICE_STATES = 128,
    GUILD_PRESENCES = 256,
    GUILD_MESSAGES = 512,
    GUILD_MESSAGE_REACTIONS = 1024,
    GUILD_MESSAGE_TYPING = 2048,
    DIRECT_MESSAGES = 4096,
    DIRECT_MESSAGE_REACTIONS = 8192,
    DIRECT_MESSAGE_TYPING = 16384,
    MESSAGE_CONTENT = 32768,
    GUILD_SCHEDULED_EVENTS = 65536,
    AUTO_MODERATION_CONFIGURATION = 1048576,
    AUTO_MODERATION_EXECUTION = 2097152,
    GUILD_MESSAGE_POLLS = 16777216,
    DIRECT_MESSAGE_POLLS = 33554432
}
export type IntentNames = keyof typeof Intents;
export type PrivilegedIntentNames = "GUILD_MEMBERS" | "GUILD_PRESENCES" | "MESSAGE_CONTENT";
export declare const NonPrivilegedIntents: readonly [Intents.GUILDS, Intents.GUILD_MODERATION, Intents.GUILD_EMOJIS_AND_STICKERS, Intents.GUILD_INTEGRATIONS, Intents.GUILD_WEBHOOKS, Intents.GUILD_INVITES, Intents.GUILD_VOICE_STATES, Intents.GUILD_MESSAGES, Intents.GUILD_MESSAGE_REACTIONS, Intents.GUILD_MESSAGE_TYPING, Intents.DIRECT_MESSAGES, Intents.DIRECT_MESSAGE_REACTIONS, Intents.DIRECT_MESSAGE_TYPING, Intents.GUILD_SCHEDULED_EVENTS, Intents.AUTO_MODERATION_CONFIGURATION, Intents.AUTO_MODERATION_EXECUTION, Intents.GUILD_MESSAGE_POLLS, Intents.DIRECT_MESSAGE_POLLS];
export declare const AllNonPrivilegedIntents: number;
export declare const PrivilegedIntents: readonly [Intents.GUILD_MEMBERS, Intents.GUILD_PRESENCES, Intents.MESSAGE_CONTENT];
export declare const AllPrivilegedIntents: number;
export declare const AllIntents: number;
export declare const PrivilegedIntentMapping: Array<[intent: Intents, allowed: Array<ApplicationFlags>]>;
export declare enum GatewayOPCodes {
    DISPATCH = 0,
    HEARTBEAT = 1,
    IDENTIFY = 2,
    PRESENCE_UPDATE = 3,
    VOICE_STATE_UPDATE = 4,
    RESUME = 6,
    RECONNECT = 7,
    REQUEST_GUILD_MEMBERS = 8,
    INVALID_SESSION = 9,
    HELLO = 10,
    HEARTBEAT_ACK = 11,
    REQUEST_SOUNDBOARD_SOUNDS = 31
}
export declare enum GatewayCloseCodes {
    UNKNOWN_ERROR = 4000,
    UNKNOWN_OPCODE = 4001,
    DECODE_ERROR = 4002,
    NOT_AUTHENTICATED = 4003,
    AUTHENTICATION_FAILED = 4004,
    ALREADY_AUTHENTICATED = 4005,
    INVALID_SEQUENCE = 4007,
    RATE_LIMITED = 4008,
    SESSION_TIMEOUT = 4009,
    INVALID_SHARD = 4010,
    SHARDING_REQUIRED = 4011,
    INVALID_API_VERSION = 4012,
    INVALID_INTENTS = 4013,
    DISALLOWED_INTENTS = 4014
}
export declare enum VoiceOPCodes {
    IDENTIFY = 0,
    SELECT_PROTOCOL = 1,
    READY = 2,
    HEARTBEAT = 3,
    SESSION_DESCRIPTION = 4,
    SPEAKING = 5,
    HEARTBEAT_ACK = 6,
    RESUME = 7,
    HELLO = 8,
    RESUMED = 9,
    CLIENTS_CONNECT = 11,
    CLIENT_DISCONNECT = 13
}
export declare enum VoiceCloseCodes {
    UNKNOWN_OPCODE = 4001,
    DECODE_ERROR = 4002,
    NOT_AUTHENTICATED = 4003,
    AUTHENTICATION_FAILED = 4004,
    ALREADY_AUTHENTICATED = 4005,
    INVALID_SESSION = 4006,
    SESSION_TIMEOUT = 4009,
    SERVER_NOT_FOUND = 4011,
    UNKNOWN_PROTOCOL = 4012,
    DISCONNECTED = 4013,
    VOICE_SERVER_CRASHED = 4014,
    UNKNOWN_ENCRYPTION_MODE = 4015
}
export declare enum HubTypes {
    DEFAULT = 0,
    HIGH_SCHOOL = 1,
    COLLEGE = 2
}
export declare enum ActivityTypes {
    GAME = 0,
    STREAMING = 1,
    LISTENING = 2,
    WATCHING = 3,
    CUSTOM = 4,
    COMPETING = 5,
    HANG_STATUS = 6
}
export declare enum ActivityFlags {
    INSTANCE = 1,
    JOIN = 2,
    SPECTATE = 4,
    JOIN_REQUEST = 8,
    SYNC = 16,
    PLAY = 32,
    PARTY_PRIVACY_FRIENDS_ONLY = 64,
    PARTY_PRIVACY_VOICE_CHANNEL = 128,
    EMBEDDED = 256
}
export declare enum ThreadMemberFlags {
    HAS_INTERACTED = 1,
    ALL_MESSAGES = 2,
    ONLY_MENTIONS = 4,
    NO_MESSAGES = 8
}
export declare enum RoleConnectionMetadataTypes {
    INTEGER_LESS_THAN_OR_EQUAL = 1,
    INTEGER_GREATER_THAN_OR_EQUAL = 2,
    INTEGER_EQUAL = 3,
    INTEGER_NOT_EQUAL = 4,
    DATETIME_LESS_THAN_OR_EQUAL = 5,
    DATETIME_GREATER_THAN_OR_EQUAL = 6,
    BOOLEAN_EQUAL = 7,
    BOOLEAN_NOT_EQUAL = 8
}
export declare enum GuildMemberFlags {
    DID_REJOIN = 1,
    COMPLETED_ONBOARDING = 2,
    BYPASSES_VERIFICATION = 4,
    STARTED_ONBOARDING = 8,
    IS_GUEST = 16,
    STARTED_HOME_ACTIONS = 32,
    COMPLETED_HOME_ACTIONS = 64,
    AUTOMOD_QUARANTINED_USERNAME_OR_GUILD_NICKNAME = 128,
    AUTOMOD_QUARANTINED_BIO = 256,
    DM_SETTINGS_UPSELL_ACKNOWLEDGED = 512,
    AUTOMOD_QUARANTINED_CLAN_TAG = 1024
}
export declare enum OnboardingPromptTypes {
    MULTIPLE_CHOICE = 0,
    DROPDOWN = 1
}
export declare enum AnimationTypes {
    PREMIUM = 0,
    BASIC = 1
}
export declare enum OnboardingModes {
    DEFAULT = 0,
    ADVANCED = 1
}
export declare enum InviteFlags {
    /** @deprecated Use `IS_GUEST_INVITE`. This will be removed in `1.15.0`. */
    GUEST = 1,
    IS_GUEST_INVITE = 1
}
export declare enum ReactionType {
    NORMAL = 0,
    SUPER = 1
}
export declare enum AttachmentFlags {
    IS_CLIP = 1,
    IS_THUMBNAIL = 2,
    IS_REMIX = 4,
    IS_SPOILER = 8,
    CONTAINS_EXPLICIT_MEDIA = 16,
    IS_ANIMATED = 32
}
export declare enum SKUTypes {
    DURABLE_PRIMARY = 1,
    DURABLE = 2,
    CONSUMABLE = 3,
    BUNDLE = 4,
    SUBSCRIPTION = 5,
    SUBSCRIPTION_GROUP = 6
}
export declare enum SKUFlags {
    PREMIUM_PURCHASE = 1,
    HAS_FREE_PREMIUM_CONTENT = 2,
    AVAILABLE = 4,
    PREMIUM_AND_DISTRIBUTION = 8,
    STICKER_PACK = 16,
    GUILD_ROLE = 32,
    AVAILABLE_FOR_SUBSCRIPTION_GIFTING = 64,
    APPLICATION_GUILD_SUBSCRIPTION = 128,
    GUILD_SUBSCRIPTION = 128,
    APPLICATION_USER_SUBSCRIPTION = 256,
    USER_SUBSCRIPTION = 256
}
export declare enum EntitlementTypes {
    PURCHASE = 1,
    PREMIUM_SUBSCRIPTION = 2,
    DEVELOPER_GIFT = 3,
    TEST_MODE_PURCHASE = 4,
    FREE_PURCHASE = 5,
    USER_GIFT = 6,
    PREMIUM_PURCHASE = 7,
    APPLICATION_SUBSCRIPTION = 8
}
export declare enum EntitlementOwnerTypes {
    GUILD = 1,
    USER = 2
}
export declare enum SKUAccessTypes {
    PUBLIC = 1
}
export declare enum SubscriptionStatuses {
    ACTIVE = 0,
    INACTIVE = 1,
    ENDING = 2
}
export declare enum PollLayoutType {
    DEFAULT = 1
}
export declare enum ApplicationMonetizationState {
    NONE = 1,
    ENABLED = 2,
    BLOCKED = 3
}
export declare enum ApplicationDiscoverabilityState {
    INELIGIBLE = 1,
    NOT_DISCOVERABLE = 2,
    DISCOVERABLE = 3,
    FEATURABLE = 4,
    BLOCKED = 5
}
export declare enum ApplicationDiscoveryEligibilityFlags {
    VERIFIED = 1,
    TAG = 2,
    DESCRIPTION = 4,
    TERMS_OF_SERVICE = 8,
    PRIVACY_POLICY = 16,
    INSTALL_PARAMS = 32,
    SAFE_NAME = 64,
    SAFE_DESCRIPTION = 128,
    APPROVED_COMMANDS = 256,
    SUPPORT_GUILD = 512,
    SAFE_COMMANDS = 1024,
    MFA = 2048,
    SAFE_DIRECTORY_OVERVIEW = 4096,
    SUPPORTED_LOCALES = 8192,
    SAFE_SHORT_DESCRIPTION = 16384,
    SAFE_ROLE_CONNECTIONS = 32768
}
export declare enum ApplicationExplicitContentFilterLevel {
    DISABLED = 0,
    ENABLED = 1
}
export declare enum ApplicationInteractionsVersion {
    VERSION_1 = 1,
    VERSION_2 = 2
}
export declare enum ApplicationMonetizationEligibilityFlags {
    VERIFIED = 1,
    HAS_TEAM = 2,
    APPROVED_COMMANDS = 4,
    TERMS_OF_SERVICE = 8,
    PRIVACY_POLICY = 16,
    SAFE_NAME = 32,
    SAFE_DESCRIPTION = 64,
    SAFE_ROLE_CONNECTIONS = 128,
    NOT_QUARANTINED = 512,
    USER_LOCALE_SUPPORTED = 1024,
    USER_AGE_SUPPORTED = 2048,
    USER_DATE_OF_BIRTH_DEFINED = 4096,
    USER_MFA_ENABLED = 8192,
    USER_EMAIL_VERIFIED = 16384,
    TEAM_MEMBERS_EMAIL_VERIFIED = 32768,
    TEAM_MEMBERS_MFA_ENABLED = 65536,
    NO_BLOCKING_ISSUES = 131072,
    VALID_PAYOUT_STATUS = 262144
}
export declare enum RPCApplicationState {
    DISABLED = 0,
    UNSUBMITTED = 1,
    SUBMITTED = 2,
    APPROVED = 3,
    REJECTED = 4
}
export declare enum StoreApplicationState {
    NONE = 1,
    PAID = 2,
    SUBMITTED = 3,
    APPROVED = 4,
    REJECTED = 5
}
export declare enum ApplicationVerificationState {
    INELIGIBLE = 1,
    UNSUBMITTED = 2,
    SUBMITTED = 3,
    SUCCEEDED = 4
}
export declare enum RoleFlags {
    IN_PROMPT = 1
}
export declare enum MemberSearchSortType {
    JOINED_AT_DESC = 1,
    JOINED_AT_ASC = 2,
    USER_ID_DESC = 3,
    USER_ID_ASC = 4
}
export declare enum MemberJoinSourceType {
    UNSPECIFIED = 0,
    BOT = 1,
    INTEGRATION = 2,
    DISCOVERY = 3,
    HUB = 4,
    INVITE = 5,
    VANITY_URL = 6,
    MANUAL_MEMBER_VERIFICATION = 7
}
export declare enum ActivityLocationKind {
    GUILD_CHANNEL = "gc",
    PRIVATE_CHANNEL = "pc"
}
export declare enum ApplicationEventWebhookStatus {
    DISABLED = 1,
    ENABLED = 2,
    DISABLED_BY_DISCORD = 3
}
export declare const ApplicationEventWebhookEventTypes: readonly ["APPLICATION_AUTHORIZED", "APPLICATION_DEAUTHORIZED", "ENTITLEMENT_CREATE", "QUEST_USER_ENROLLMENT"];
export type ApplicationEventWebhookEventType = typeof ApplicationEventWebhookEventTypes[number];
export declare enum EmbedFlags {
    CONTAINS_EXPLICIT_MEDIA = 16,
    IS_CONTENT_INVENTORY_ENTRY = 32
}
export declare enum EmbedMediaFlags {
    IS_ANIMATED = 32
}
export declare enum SeparatorSpacingSize {
    SMALL = 1,
    LARGE = 2
}
export declare enum DisplayNameFont {
    BANGERS = 1,
    BIO_RHYME = 2,
    CHERRY_BOMB = 3,
    CHICLE = 4,
    COMPAGNON = 5,
    MUSEO_MODERNO = 6,
    NEO_CASTEL = 7,
    PIXELFY = 8,
    RIBES = 9,
    SINISTRE = 10,
    DEFAULT = 11,
    ZILLA_SLAB = 12
}
export declare enum DisplayNameEffect {
    SOLID = 1,
    GRADIENT = 2,
    NEON = 3,
    TOON = 4,
    POP = 5,
    GLOW = 6
}
export declare enum InviteTargetUsersJobStatus {
    UNSPECIFIED = 0,
    PROCESSING = 1,
    COMPLETED = 2,
    FAILED = 3
}
export declare enum ApplicationInternalGuildRestriction {
    JOIN_ALL = 1,
    JOIN_EXTERNAL_ONLY = 2,
    JOIN_INTERNAL_ONLY = 3
}
export declare enum EmbeddedActivityOrientationLockStateType {
    UNLOCKED = 1,
    PORTRAIT = 2,
    LANDSCAPE = 3
}
export declare enum EmbeddedActivityLabelType {
    NONE = 0,
    NEW = 1,
    UPDATED = 2
}
export declare const EmbeddedActivityReleasePhases: readonly ["in_development", "activities_team", "employee_release", "soft_launch", "soft_launch_multi_geo", "global_launch"];
export type EmbeddedActivityReleasePhase = typeof EmbeddedActivityReleasePhases[number];
export declare const EmbeddedActivitySurfaces: readonly ["voice_launcher", "text_launcher"];
export type EmbeddedActivitySurface = typeof EmbeddedActivitySurfaces[number];
export declare const EmbeddedActivityPlatformTypes: readonly ["web", "android", "ios"];
export type EmbeddedActivityPlatformType = typeof EmbeddedActivityPlatformTypes[number];
export declare const PricingLocalizationStrategies: readonly ["localized_price_sets"];
export type PricingLocalizationStrategy = typeof PricingLocalizationStrategies[number];
export declare const OperatingSystemTypes: readonly ["windows", "osx", "linux", "android", "ios", "playstation", "xbox", "unknown"];
export type OperatingSystemType = typeof OperatingSystemTypes[number];
export declare const TeamMemberRoleTypes: readonly ["admin", "developer", "read_only"];
export type TeamMemberRoleType = typeof TeamMemberRoleTypes[number];
export declare enum ApprovableConsoleType {
    XBOX = 1,
    PLAYSTATION_5 = 2,
    PLAYSTATION_4 = 3
}
export declare enum OverlayMethodFlags {
    OUT_OF_PROCESS = 1
}
export declare enum TeamPayoutAccountStatus {
    UNSUBMITTED = 1,
    PENDING = 2,
    ACTION_REQUIRED = 3,
    ACTIVE = 4,
    BLOCKED = 5,
    SUSPENDED = 6
}
export declare enum TeamPayoutGateway {
    STRIPE_TOPUP = 1,
    TIPALTI = 2,
    STRIPE_PRIMARY = 3
}
export declare enum ApplicationType {
    DEPRECATED_GAME = 1,
    MUSIC = 2,
    TICKETED_EVENTS = 3,
    CREATOR_MONETIZATION = 4,
    GAME = 5
}
export declare enum LobbyMemberFlags {
    CAN_LINK_LOBBY = 1
}
export declare enum MessageReferenceType {
    DEFAULT = 0,
    FORWARD = 1
}
/** The error codes that can be received. See [Discord's Documentation](https://discord.com/developers/docs/topics/opcodes-and-status-codes#json). */
export declare enum JSONErrorCodes {
    GENERAL_ERROR = 0,
    UNKNOWN_ACCOUNT = 10001,
    UNKNOWN_APPLICATION = 10002,
    UNKNOWN_CHANNEL = 10003,
    UNKNOWN_GUILD = 10004,
    UNKNOWN_INTEGRATION = 10005,
    UNKNOWN_INVITE = 10006,
    UNKNOWN_MEMBER = 10007,
    UNKNOWN_MESSAGE = 10008,
    UNKNOWN_OVERWRITE = 10009,
    UNKNOWN_PROVIDER = 10010,
    UNKNOWN_PLATFORM = 10010,
    UNKNOWN_ROLE = 10011,
    UNKNOWN_TOKEN = 10012,
    UNKNOWN_USER = 10013,
    UNKNOWN_EMOJI = 10014,
    UNKNOWN_WEBHOOK = 10015,
    UNKNOWN_WEBHOOK_SERVICE = 10016,
    UNKNOWN_SESSION = 10020,
    UNKNOWN_ASSET = 10021,
    UNKNOWN_BAN = 10026,
    UNKNOWN_SKU = 10027,
    UNKNOWN_STORE_LISTING = 10028,
    UNKNOWN_ENTITLEMENT = 10029,
    UNKNOWN_BUILD = 10030,
    UNKNOWN_LOBBY = 10031,
    UNKNOWN_BRANCH = 10032,
    UNKNOWN_STORE_DIRECTORY_LAYOUT = 10036,
    UNKNOWN_REDISTRIBUTABLE = 10037,
    UNKNOWN_GIFT_CODE = 10038,
    UNKNOWN_STREAM = 10049,
    UNKNOWN_PREMIUM_SERVER_SUBSCRIBE_COOLDOWN = 10050,
    UNKNOWN_GUILD_TEMPLATE = 10057,
    UNKNOWN_DISCOVERABLE_SERVER_CATEGORY = 10059,
    UNKNOWN_STICKER = 10060,
    UNKNOWN_INTERACTION = 10062,
    UNKNOWN_APPLICATION_COMMAND = 10063,
    UNKNOWN_APPLICATION_COMMAND_PERMISSIONS = 10066,
    UNKNOWN_STAGE_INSTANCE = 10067,
    UNKNOWN_GUILD_MEMBER_VERIFICATION_FORM = 10068,
    UNKNOWN_GUILD_WELCOME_SCREEN = 10069,
    UNKNOWN_GUILD_SCHEDULED_EVENT = 10070,
    UNKNOWN_GUILD_SCHEDULED_EVENT_USER = 10071,
    UNKNOWN_TAG = 10087,
    UNKNOWN_SOUND = 10097,
    BOT_DISALLOWED = 20001,
    BOTS_CANNOT_USE_THIS_ENDPOINT = 20001,
    BOT_REQUIRED = 20002,
    ONLY_BOTS_CAN_USE_THIS_ENDPOINT = 20002,
    RPC_PROXY_DISALLOWED = 20003,
    EXPLICIT_CONTENT = 20009,
    ACCOUNT_SCHEDULED_FOR_DELETION = 20011,
    NOT_AUTHORIZED_FOR_APPLICATION = 20012,
    ACCOUNT_DISABLED = 20013,
    SLOWMODE_RATE_LIMITED = 20016,
    ACCOUNT_OWNER_ONLY = 20018,
    CHANNEL_FOLLOWING_EDIT_RATE_LIMITED = 20022,
    UNDER_MINIMUM_AGE = 20024,
    QUARANTINED = 20026,
    CHANNEL_WRITE_RATE_LIMIT = 20028,
    GUILD_WRITE_RATE_LIMIT = 20029,
    WORDS_NOT_ALLOWED = 20031,
    VANITY_URL_REQUIRED_FOR_PUBLISHED_GUILDS = 20040,
    VANITY_URL_EMPLOYEE_ONLY_GUILD_DISABLED = 20044,
    VANITY_URL_REQUIREMENTS_NOT_MET = 20045,
    TOO_MANY_GUILDS = 30001,
    TOO_MANY_FRIENDS = 30002,
    TOO_MANY_PINS_IN_CHANNEL = 30003,
    TOO_MANY_RECIPIENTS = 30004,
    TOO_MANY_GUILD_ROLES = 30005,
    TOO_MANY_USING_USERNAME = 30006,
    TOO_MANY_WEBHOOKS = 30007,
    TOO_MANY_EMOJI = 30008,
    TOO_MANY_REACTIONS = 30010,
    TOO_MANY_GROUP_CHANNELS = 30011,
    TOO_MANY_CHANNELS = 30013,
    TOO_MANY_ATTACHMENTS = 30015,
    TOO_MANY_INVITES = 30016,
    TOO_MANY_ANIMATED_EMOJI = 30018,
    GUILD_AT_CAPACITY = 30019,
    NOT_ENOUGH_GUILD_MEMBERS = 30029,
    TOO_MANY_SERVER_CATEGORIES = 30030,
    GUILD_ALREADY_HAS_TEMPLATE = 30031,
    TOO_MANY_APPLICATION_COMMANDS = 30032,
    TOO_MANY_THREAD_MEMBERS = 30033,
    TOO_MANY_APPLICATION_COMMAND_CREATES = 30034,
    TOO_MANY_BANS_FOR_NON_GUILD_MEMBERS = 30035,
    TOO_MANY_BAN_FETCHES = 30037,
    TOO_MANY_UNCOMPLETED_GUILD_SCHEDULED_EVENTS = 30038,
    TOO_MANY_STICKERS = 30039,
    TOO_MANY_PRUNE_REQUESTS = 30040,
    TOO_MANY_GUILD_WIDGET_SETTINGS_UPDATES = 30042,
    TOO_MANY_SOUNDBOARD_SOUNDS = 30045,
    MAXIMUM_NUMBER_OR_EDITS_TO_MESSAGES_OLDER_THAN_1_HOUR = 30046,
    TOO_MANY_PINNED_THREADS = 30047,
    TOO_MANY_FORUM_TAGS = 30048,
    BITRATE_TOO_HIGH = 30052,
    TOO_MANY_PREMIUM_EMOJIS = 30056,
    TOO_MANY_GUILD_WEBHOOKS = 30058,
    TOO_MANY_BLOCKED_USERS = 30059,
    TOO_MANY_PUBLISHED_PRODUCT_LISTINGS = 30065,
    RESOURCE_RATE_LIMITED = 31002,
    UNAUTHORIZED = 40001,
    EMAIL_VERIFICATION_REQUIRED = 40002,
    RATE_LIMIT_DM_OPEN = 40003,
    DIRECT_MESSAGES_RATE_LIMIT = 40003,
    SENDING_MESSAGES_TEMPORARILY_DISABLED = 40004,
    ENTITY_TOO_LARGE = 40005,
    REQUEST_ENTITY_TOO_LARGE = 40005,
    ENTITY_EMPTY = 40006,
    FEATURE_TEMPORARILY_DISABLED = 40006,
    USER_BANNED = 40007,
    CONNECTION_REVOKED = 40012,
    DELETE_ACCOUNT_TRANSFER_TEAM_OWNERSHIP = 40028,
    TARGET_USER_NOT_CONNECTED_TO_VOICE = 40032,
    ALREADY_CROSSPOSTED = 40033,
    APPLICATION_COMMAND_ALREADY_EXISTS = 40041,
    INTERACTION_FAILED_TO_SEND = 40043,
    CANNOT_SEND_MESSAGES_IN_FORUM_CHANNEL = 40058,
    INTERACTION_ALREADY_ACKNOWLEDGED = 40060,
    TAG_NAMES_MUST_BE_UNIQUE = 40061,
    SERVICE_RESOURCE_RATE_LIMITED = 40062,
    NON_MODERATED_TAG_REQUIRED = 40066,
    TAG_REQUIRED = 40067,
    USER_QUARANTINED = 40068,
    INVITES_DISABLED = 40069,
    ENTITLEMENT_ALREADY_GRANTED = 40074,
    CLOUDFLARE_BLOCKING_REQUEST = 40333,
    INVALID_ACCESS = 50001,
    MISSING_ACCESS = 50001,
    INVALID_ACCOUNT_TYPE = 50002,
    INVALID_ACTION_DM = 50003,
    INVALID_EMBED_DISABLED = 50004,
    INVALID_MESSAGE_AUTHOR = 50005,
    INVALID_MESSAGE_EMPTY = 50006,
    INVALID_MESSAGE_SEND_USER = 50007,
    INVALID_MESSAGE_SEND_NON_TEXT = 50008,
    INVALID_MESSAGE_VERIFICATION_LEVEL = 50009,
    INVALID_OAUTH_APP_BOT = 50010,
    INVALID_OAUTH_APP_LIMIT = 50011,
    INVALID_OAUTH_STATE = 50012,
    INVALID_PERMISSIONS = 50013,
    INVALID_TOKEN = 50014,
    INVALID_NOTE = 50015,
    INVALID_BULK_DELETE_COUNT = 50016,
    INVALID_MFA_LEVEL = 50017,
    INVALID_PASSWORD = 50018,
    INVALID_PIN_MESSAGE_CHANNEL = 50019,
    INVALID_INVITE_CODE = 50020,
    CANNOT_EXECUTE_ON_SYSTEM_MESSAGE = 50021,
    INVALID_PHONE_NUMBER = 50022,
    INVALID_CLIENT_ID = 50023,
    INVALID_CHANNEL_TYPE = 50024,
    INVALID_OAUTH2_ACCESS_TOKEN = 50025,
    INVALID_OAUTH2_MISSING_SCOPE = 50026,
    INVALID_WEBHOOK_TOKEN = 50027,
    INVALID_ROLE = 50028,
    INVALID_RECIPIENTS = 50033,
    BULK_DELETE_MESSAGE_TOO_OLD = 50034,
    INVALID_FORM_BODY = 50035,
    INVITE_ACCEPTED_TO_GUILD_NOT_CONTAINING_BOT = 50036,
    INVALID_ACTIVITY_ACTION = 500039,
    INVALID_API_VERSION = 50041,
    INVALID_FILE_ASSET_SIZE = 50045,
    INVALID_FILE_ASSET = 50046,
    INVALID_GIFT_REDEMPTION_EXHAUSTED = 50050,
    INVALID_GIFT_REDEMPTION_OWNED = 50051,
    INVALID_GIFT_SELF_REDEMPTION = 50054,
    INVALID_GUILD = 50055,
    INVALID_REQUEST_ORIGIN = 50067,
    INVALID_MESSAGE_TYPE = 50068,
    PAYMENT_SOURCE_REQUIRED = 50070,
    CANNOT_MODIFY_SYSTEM_WEBHOOK = 50073,
    CANNOT_DELETE_COMMUNITY_REQUIRED_CHANNEL = 50074,
    CANNOT_EDIT_MESSAGE_STICKERS = 50080,
    INVALID_STICKER_SENT = 50081,
    THREAD_ARCHIVED = 50083,
    INVALID_THREAD_NOTIFICATION_SETTINGS = 50084,
    BEFORE_EARLIER_THAN_THREAD_CREATION_DATE = 50085,
    COMMUNITY_CHANNELS_MUST_BE_TEXT = 50086,
    INVALID_COUNTRY_CODE = 50095,
    INVALID_CANNOT_FRIEND_SELF = 50096,
    INVALID_GIFT_REDEMPTION_FRAUD_REJECTED = 50097,
    MONETIZATION_REQUIRED = 50097,
    BOOSTS_REQUIRED = 50101,
    INVALID_USER_SETTINGS_DATA = 50105,
    INVALID_ACTIVITY_LAUNCH_NO_ACCESS = 50106,
    INVALID_ACTIVITY_LAUNCH_PREMIUM_TIER = 50107,
    INVALID_ACTIVITY_LAUNCH_CONCURRENT_ACTIVITIES = 50108,
    INVALID_JSON = 50109,
    INVALID_PROVIDED_FILE = 50110,
    INVALID_PROVIDED_FILE_TYPE = 50123,
    INVALID_PROVIDED_FILE_DURATION = 50124,
    OWNER_CANNOT_BE_PENDING_MEMBER = 50131,
    OWNERSHIP_CANNOT_BE_TRANSFERRED_TO_BOT = 50132,
    INVALID_FILE_ASSET_SIZE_RESIZE_GIF = 50138,
    CANNOT_MIX_SUBSCRIPTION_AND_NON_SUBSCRIPTION_ROLES = 50144,
    CANNOT_CONVERT_BETWEEN_PREMIUM_AND_NORMAL_EMOJI = 50145,
    UPLOADED_FILE_NOT_FOUND = 50146,
    INVALID_SPECIFIED_EMOJI = 50151,
    INVALID_ACTIVITY_LAUNCH_AFK_CHANNEL = 50148,
    VOICE_MESSAGES_DO_NOT_SUPPORT_ADDITIONAL_CONTENT = 50159,
    VOICE_MESSAGES_MUST_HAVE_A_SINGLE_AUDIO_ATTACHMENT = 50160,
    VOICE_MESSAGES_MUST_HAVE_SUPPORTING_METADATA = 50161,
    VOICE_MESSAGES_CANNOT_BE_EDITED = 50162,
    CANNOT_DELETE_GUILD_SUBSCRIPTION_INTEGRATION = 50163,
    NEW_OWNER_INELIGIBLE_FOR_SERVER_SUBSCRIPTION = 50164,
    INVALID_ACTIVITY_LAUNCH_AGE_GATED = 50165,
    CANNOT_SEND_VOICE_MESSAGES_IN_CHANNEL = 50173,
    USER_MUST_FIRST_BE_VERIFIED = 50178,
    PROVIDED_FILE_HAS_INVALID_DURATION = 50192,
    INVALID_SKU_ATTACHMENT_NO_ARCHIVES = 50186,
    NO_PERMISSION_TO_SEND_STICKER = 50600,
    MFA_ENABLED = 60001,
    MFA_DISABLED = 60002,
    MFA_REQUIRED = 60003,
    MFA_UNVERIFIED = 60004,
    MFA_INVALID_SECRET = 60005,
    MFA_INVALID_TICKET = 60006,
    MFA_INVALID_CODE = 60008,
    MFA_INVALID_SESSION = 60009,
    PHONE_NUMBER_UNABLE_TO_SEND = 70003,
    PHONE_VERIFICATION_REQUIRED = 70007,
    RELATIONSHIP_INCOMING_DISABLED = 80000,
    RELATIONSHIP_INCOMING_BLOCKED = 80001,
    RELATIONSHIP_INVALID_USER_BOT = 80002,
    RELATIONSHIP_INVALID_SELF = 80003,
    RELATIONSHIP_INVALID_DISCORD_TAG = 80004,
    RELATIONSHIP_ALREADY_FRIENDS = 80007,
    REACTION_BLOCKED = 90001,
    USER_CANNOT_USE_BURST_REACTIONS = 90002,
    INVALID_GIFT_REDEMPTION_SUBSCRIPTION_MANAGED = 100021,
    INVALID_GIFT_REDEMPTION_SUBSCRIPTION_INCOMPATIBLE = 100023,
    INVALID_GIFT_REDEMPTION_INVOICE_OPEN = 100024,
    INELIGIBLE_FOR_SUBSCRIPTION = 100053,
    BILLING_NON_REFUNDABLE_PAYMENT_SOURCE = 100060,
    INDEX_NOT_YET_AVAILABLE = 110000,
    APPLICATION_NOT_AVAILABLE = 110001,
    LISTING_ALREADY_JOINED = 120000,
    LISTING_TOO_MANY_MEMBERS = 120001,
    LISTING_JOIN_BLOCKED = 120002,
    API_RESOURCE_IS_CURRENTLY_OVERLOADED = 130000,
    STAGE_ALREADY_OPEN = 150006,
    CANNOT_REPLY_WITHOUT_READ_MESSAGE_HISTORY = 160002,
    THREAD_ALREADY_CREATED_FOR_MESSAGE = 160004,
    THREAD_IS_LOCKED = 160005,
    TOO_MANY_THREADS = 160006,
    TOO_MANY_ANNOUNCEMENT_THREADS = 160007,
    INVALID_LOTTIE_JSON = 170001,
    UPLOADED_LOTTIE_RASTERIZED = 170002,
    STICKER_MAXIMUM_FRAMERATE_EXCEEDED = 170003,
    STICKER_FRAME_COUNT_EXCEEDS_MAXIMUM = 170004,
    LOTTIE_ANIMATION_MAXIMUM_DIMENSIONS_EXCEEDED = 170005,
    STICKER_FRAME_RATE_TOO_SMALL_OR_LARGE = 170006,
    STICKER_ANIMATION_DURATION_TOO_LONG = 170007,
    POGGERMODE_TEMPORARILY_DISABLED = 170008,
    CANNOT_UPDATE_FINISHED_EVENT = 180000,
    FAILED_TO_CREATE_STAGE_INSTANCE = 180002,
    AUTOMOD_MESSAGE_BLOCKED = 200000,
    AUTOMOD_TITLE_BLOCKED = 200001,
    AUTOMOD_INVALID_RUST_SERVICE_RESPONSE = 200002,
    MONETIZATION_TERMS_NOT_ACCEPTED = 210003,
    TWO_FA_NOT_ENABLED = 210011,
    GUILD_PRODUCT_LISTING_CANNOT_PUBLISH_WITHOUT_BENEFIT = 210021,
    CREATOR_MONETIZATION_PAYMENT_TEAM_REQUIRED = 210026,
    CREATOR_MONETIZATION_PAYMENT_ACCOUNT_VERIFICATION_REQUIRED = 210027,
    WEBHOOKS_POSTED_TO_FORUM_CHANNELS_MUST_HAVE_THREAD_NAME_OR_THREAD_ID = 220001,
    WEBHOOKS_POSTED_TO_FORUM_CHANNELS_CANNOT_HAVE_BOTH_THREAD_NAME_AND_THREAD_ID = 220002,
    WEBHOOKS_CAN_ONLY_CREATE_THREADS_IN_FORUM_CHANNELS = 220003,
    WEBHOOK_SERVICES_CANNOT_BE_USED_IN_FORUM_CHANNELS = 220004,
    MESSAGE_BLOCKED_BY_HARMFUL_LINKS_FILTER = 220005,
    HARMFUL_LINK_MESSAGE_BLOCKED = 240000,
    CLYDE_CONSENT_REQUIRED = 310000,
    CLYDE_UNSAFE_PERSONALITY = 310003,
    USER_LIMITED_ACCESS_DEFAULT = 340000,
    USER_FRIEND_REQUEST_LIMITED_ACCESS = 340007,
    USER_LIMITED_ACCESS_MAX = 349999,
    CANNOT_ENABLE_ONBOARDING_REQUIREMENTS_NOT_MET = 350000,
    CANNOT_ENABLE_ONBOARDING_BELOW_REQUIREMENTS = 350001,
    GUILD_LIMITED_ACCESS_DEFAULT = 400000,
    GUILD_FILE_UPLOAD_RATE_LIMITED_ACCESS = 400001,
    GUILD_JOIN_INVITE_LIMITED_ACCESS = 400002,
    GUILD_GO_LIVE_LIMITED_ACCESS = 400003,
    GUILD_LIMITED_ACCESS_MAX = 409999,
    FAILED_TO_BAN_USERS = 500000,
    POLL_VOTING_BLOCKED = 520000,
    POLL_EXPIRED = 520001,
    INVALID_CHANNEL_TYPE_FOR_POLL_CREATION = 520002,
    CANNOT_EDIT_POLL_MESSAGE = 520003,
    CANNOT_USE_AN_EMOJI_INCLUDED_WITH_THE_POLL = 520004,
    CANNOT_EXPIRE_A_NON_POLL_MESSAGE = 520006,
    POLL_IS_ALREADY_EXPIRED = 520007,
    APPLICATION_PROVISIONAL_ACCOUNTS_NOT_GRANTED = 530000,
    JWT_TOKEN_EXPIRED = 530001,
    JWT_TOKEN_ISSUER_MISMATCH = 530002,
    JWT_TOKEN_AUDIENCE_MISMATCH = 530003,
    JWT_TOKEN_ISSUED_TOO_LONG_AGO = 530004,
    UNIQUE_USERNAME_GENERATION_FAILED = 530006,
    CLIENT_SECRET_INVALID = 530007
}
