/** @module Message */
import Base from "./Base";
import Attachment from "./Attachment";
import User from "./User";
import type Guild from "./Guild";
import type Member from "./Member";
import PartialApplication from "./PartialApplication";
import type ClientApplication from "./ClientApplication";
import type AnnouncementChannel from "./AnnouncementChannel";
import type AnnouncementThreadChannel from "./AnnouncementThreadChannel";
import type PublicThreadChannel from "./PublicThreadChannel";
import type TextChannel from "./TextChannel";
import type PrivateChannel from "./PrivateChannel";
import Poll from "./Poll";
import type * as Types from "../types/namespaced";
import type Client from "../Client";
import TypedCollection from "../util/TypedCollection";
import { type MessageTypes } from "../Constants";
/** Represents a message. */
export default class Message<T extends Types.Channels.AnyTextableChannel | Types.Shared.Uncached = Types.Channels.AnyTextableChannel | Types.Shared.Uncached> extends Base {
    private _cachedChannel;
    private _cachedGuild?;
    /** The [activity](https://discord.com/developers/docs/resources/channel#message-object-message-activity-structure) associated with this message. */
    activity?: Types.Channels.MessageActivity;
    /**
     * The application associated with this message. This can be present in two scenarios:
     * * If the message was from an interaction or application owned webhook ({@link ClientApplication} if any shard has reached READY, {@link PartialApplication} otherwise).
     * * If the message has a rich presence embed ({@link PartialApplication})
     */
    application?: PartialApplication | ClientApplication;
    /**
     * The ID of the application associated with this message. This can be present in two scenarios:
     * * If the message was from an interaction or application owned webhook ({@link ClientApplication} if any shard has reached READY, {@link PartialApplication} otherwise).
     * * If the message has a rich presence embed ({@link PartialApplication})
     */
    applicationID: string | null;
    /** The attachments on this message. */
    attachments: TypedCollection<Types.Channels.RawAttachment, Attachment>;
    /** The author of this message. */
    author: User;
    /** The call associated with this message. */
    call?: Types.Channels.Call;
    /** The ID of the channel this message was created in. */
    channelID: string;
    /** The components on this message. */
    components: Array<Types.Channels.MessageComponent>;
    /** The content of this message. */
    content: string;
    /** The timestamp at which this message was last edited. */
    editedTimestamp: Date | null;
    /** The embeds on this message. */
    embeds: Array<Types.Channels.Embed>;
    /** The [flags](https://discord.com/developers/docs/resources/channel#message-object-message-flags) on this message. */
    flags: number;
    /** The ID of the guild this message is in. */
    guildID: T extends Types.Channels.AnyTextableGuildChannel ? string : string | null;
    /**
     * The interaction info, if this message was the result of an interaction.
     * @deprecated Use {@link Message#interactionMetadata | Message#interactionMetadata } instead.
     */
    interaction?: Types.Channels.MessageInteraction;
    /** The interaction info, if this message was the result of an interaction. */
    interactionMetadata?: Types.Channels.AnyMessageInteractionMetadata;
    /** The member that created this message, if this message is in a guild. */
    member: T extends Types.Channels.AnyTextableGuildChannel ? Member : Member | undefined;
    /** Channels mentioned in a `CROSSPOSTED` channel follower message. See [Discord's docs](https://discord.com/developers/docs/resources/channel#channel-mention-object) for more information. */
    mentionChannels?: Array<Types.Channels.ChannelMention>;
    /** The mentions in this message. */
    mentions: Types.Channels.MessageMentions;
    /** If this message is a `REPLY` or `THREAD_STARTER_MESSAGE`, some info about the referenced message. */
    messageReference?: Types.Channels.MessageReference;
    /** If this message is a forwarded message, the partial contents of that message. */
    messageSnapshots?: Array<Types.Channels.MessageSnapshot>;
    /** A nonce for ensuring a message was sent. */
    nonce?: number | string;
    /** If this message is pinned. */
    pinned: boolean;
    /** The poll on this message, if any. */
    poll?: Poll;
    /** The poll results extracted from the embeds of this message. This will only be present for {@link Constants~MessageTypes.POLL_RESULT | POLL_RESULT } messages. */
    pollResults?: Types.Channels.MessagePollResults;
    /** This message's relative position, if in a thread. */
    position?: number;
    /** The reactions on this message. */
    reactions: Array<Types.Channels.MessageReaction>;
    /** If this message is a `REPLY` or `THREAD_STARTER_MESSAGE`, this will be the message that's referenced. */
    referencedMessage?: Message | null;
    /** The data of the role subscription purchase or renewal that prompted this message. */
    roleSubscriptionData?: Types.Channels.RoleSubscriptionData;
    /** The sticker items on this message. */
    stickerItems?: Array<Types.Channels.StickerItem>;
    /** The thread associated with this message, if any. */
    thread?: Types.Channels.AnyThreadChannel;
    /** The timestamp at which this message was sent. */
    timestamp: Date;
    /** If this message was read aloud. */
    tts: boolean;
    /** The [type](https://discord.com/developers/docs/resources/channel#message-object-message-types) of this message. */
    type: MessageTypes;
    /** The webhook associated with this message, if sent via a webhook. This only has an `id` property. */
    webhookID?: string;
    constructor(data: Types.Channels.RawMessage, client: Client);
    protected update(data: Partial<Types.Channels.RawMessage>): void;
    /** The channel this message was created in. */
    get channel(): T extends Types.Channels.AnyTextableChannel ? T : undefined;
    /** The guild this message is in. This will throw an error if the guild is not cached. */
    get guild(): T extends Types.Channels.AnyTextableGuildChannel ? Guild : Guild | null;
    /** A link to this message. */
    get jumpLink(): string;
    /**
     * Add a reaction to this message.
     * @param emoji The reaction to add to the message. `name:id` for custom emojis, and the unicode codepoint for default emojis.
     */
    createReaction(emoji: string): Promise<void>;
    /**
     * Crosspost this message in an announcement channel.
     */
    crosspost(): Promise<Message<T>>;
    /**
     * Delete this message.
     * @param reason The reason for deleting the message.
     */
    delete(reason?: string): Promise<void>;
    /**
     * Remove a reaction from this message.
     * @param emoji The reaction to remove from the message. `name:id` for custom emojis, and the unicode codepoint for default emojis.
     * @param user The user to remove the reaction from, `@me` for the current user (default).
     */
    deleteReaction(emoji: string, user?: string): Promise<void>;
    /**
     * Remove all, or a specific emoji's reactions from this message.
     * @param emoji The reaction to remove from the message. `name:id` for custom emojis, and the unicode codepoint for default emojis. Omit to remove all reactions.
     */
    deleteReactions(emoji?: string): Promise<void>;
    /**
     * Delete this message as a webhook.
     * @param token The token of the webhook.
     * @param options Options for deleting the message.
     */
    deleteWebhook(token: string, options: Types.Webhooks.DeleteWebhookMessageOptions): Promise<void>;
    /**
     * Edit this message.
     * @param options The options for editing the message.
     */
    edit(options: Types.Channels.EditMessageOptions): Promise<Message<T>>;
    /**
     * Edit this message.
     * @param content The content for editing the message
     * @param options The options for editing the message.
     */
    edit(content: string, options?: Types.Channels.EditMessageOptions): Promise<Message<T>>;
    /**
     * Edit this message as a webhook.
     * @param token The token of the webhook.
     * @param options The options for editing the message.
     */
    editWebhook(token: string, options: Types.Webhooks.EditWebhookMessageOptions): Promise<Message<T>>;
    /**
     * Edit this message as a webhook.
     * @param token The token of the webhook.
     * @param content The content for editing the message
     * @param options The options for editing the message.
     */
    editWebhook(token: string, content: string, options?: Types.Webhooks.EditWebhookMessageOptions): Promise<Message<T>>;
    /** End the poll on this message now. */
    expire(): Promise<void>;
    /**
     * Forward this message.
     * @param channelID The ID of the channel to forward the message to.
     * @param options The options for the message.
     */
    forward(channelID: string, options?: Types.Channels.CreateMessageOptions): Promise<Message<T>>;
    /**
     * Forward this message.
     * @param channelID The ID of the channel to forward the message to.
     * @param content The content for the message.
     * @param options The options for the message.
     */
    forward(channelID: string, content: string, options?: Types.Channels.CreateMessageOptions): Promise<Message<T>>;
    /**
     * Get the users that voted on a poll answer.
     * @param answerID The ID of the poll answer to get voters for.
     * @param options The options for getting the voters.
     */
    getPollAnswerUsers(answerID: number, options?: Types.Channels.GetPollAnswerUsersOptions): Promise<Array<User>>;
    /**
     * Get the users who reacted with a specific emoji on this message.
     * @param emoji The reaction to remove from the message. `name:id` for custom emojis, and the unicode codepoint for default emojis.
     * @param options The options for getting the reactions.
     */
    getReactions(emoji: string, options?: Types.Channels.GetReactionsOptions): Promise<Array<User>>;
    /** Whether this message belongs to a cached guild channel. The only difference on using this method over a simple if statement is to easily update all the message properties typing definitions based on the channel it belongs to. */
    inCachedGuildChannel(): this is Message<Types.Channels.AnyTextableGuildChannel>;
    /** Whether this message belongs to a direct message channel (PrivateChannel or uncached). The only difference on using this method over a simple if statement is to easily update all the message properties typing definitions based on the channel it belongs to. */
    inDirectMessageChannel(): this is Message<PrivateChannel | Types.Shared.Uncached>;
    /**
     * Pin this message.
     * @param reason The reason for pinning the message.
     */
    pin(reason?: string): Promise<void>;
    /**
     * Reply to this message
     * @param options The options for the message.
     */
    reply(options: Types.Channels.CreateMessageOptions): Promise<Message<T>>;
    /**
     * Reply to this message
     * @param content The content for the message.
     * @param options The options for the message.
     */
    reply(content: string, options?: Types.Channels.CreateMessageOptions): Promise<Message<T>>;
    /**
     * Create a thread from this message.
     * @param options The options for creating the thread.
     */
    startThread(options: Types.Channels.StartThreadFromMessageOptions): Promise<T extends AnnouncementChannel ? AnnouncementThreadChannel : T extends TextChannel ? PublicThreadChannel : never>;
    toJSON(): Types.JSON.JSONMessage;
    /**
     * Unpin this message.
     * @param reason The reason for unpinning the message.
     */
    unpin(reason?: string): Promise<void>;
}
